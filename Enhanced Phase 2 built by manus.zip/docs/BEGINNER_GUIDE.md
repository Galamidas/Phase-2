# Beginner's Guide to Understanding and Debugging the Code

This guide is designed for users with limited coding experience to help you understand the structure of the Phase 2 AI Analysis App, how the different components work together, and how to debug common issues.

## Understanding the Project Structure

The application is organized into several directories, each serving a specific purpose:

### 1. `app.py` - The Main Entry Point

This is the file you run to start the application (`streamlit run app.py`). It contains:

*   **Page Configuration:** Sets up the page title, icon, and layout.
*   **Main Function:** Orchestrates the UI, validates configuration, and routes to different pages based on sidebar selection.
*   **Navigation:** Calls functions from the `src/ui/` directory to render different pages.

**Key Concept:** Think of `app.py` as the "conductor" of an orchestra. It doesn't play any instruments itself, but it tells each section (UI components) when to perform.

### 2. `config/config.py` - Configuration Management

This file loads environment variables from your `.env` file and provides them to the rest of the application. It includes:

*   **API Keys:** Supabase, OpenAI, TopStep, Databento, Stripe, etc.
*   **Application Settings:** Supported symbols, table names, analysis parameters.
*   **Validation:** Checks that required configuration variables are set.

**Key Concept:** This is like a "settings panel" for your application. All sensitive information (API keys) should be stored here, not hardcoded in other files.

### 3. `src/` Directory - Core Application Logic

This directory contains all the functional modules of the application:

#### a. `src/ui/` - User Interface Components

*   **`sidebar.py`:** Renders the navigation menu and filter options on the left side of the app.
*   **`dashboard.py`:** Displays the main dashboard with key metrics and recent activity.
*   **`analysis.py`:** Shows in-depth trade analysis with various metrics (MFE/MAE, R:R, etc.).
*   **`charts.py`:** Renders interactive charts with Plotly.
*   **`insights.py`:** Displays AI-powered insights, predictions, and recommendations.

**Key Concept:** Each file in `src/ui/` is responsible for rendering a specific page or component. They use Streamlit functions like `st.title()`, `st.metric()`, `st.plotly_chart()`, etc.

#### b. `src/database/` - Database Operations

*   **`supabase_client.py`:** Handles all interactions with the Supabase database (fetching journals, trades, inserting data, etc.).

**Key Concept:** This is the "data layer" of your application. Whenever you need to read or write data to Supabase, you use functions from this file.

#### c. `src/integrations/` - External API Clients

*   **`topstep_client.py`:** Fetches trade data from the TopStep API.
*   **`databento_client.py`:** Fetches market data (OHLCV candles) from the Databento API.

**Key Concept:** These files act as "translators" between your application and external services. They handle authentication, API requests, and data transformation.

#### d. `src/analysis/` - Analysis and AI Logic

*   **`nlp_processor.py`:** Uses OpenAI to analyze journal entries, extract tags, and determine sentiment.
*   **`trade_analytics.py`:** Calculates mathematical metrics like win rate, profit factor, MFE/MAE, etc.
*   **`predictive_engine.py`:** Generates prescriptive recommendations and predictive insights using ML models.

**Key Concept:** This is the "brain" of your application. These modules process raw data and turn it into actionable insights.

#### e. `src/visualization/` - Chart Creation

*   **`chart_builder.py`:** Creates interactive Plotly charts (candlesticks, equity curves, etc.).

**Key Concept:** This module takes data and turns it into visual representations (charts and graphs).

#### f. `src/auth/` - Authentication and Subscriptions

*   **`auth_manager.py`:** Handles user login, signup, logout, and subscription management with Stripe.

**Key Concept:** This ensures that only authorized users can access the application and manages subscription tiers.

## How the Application Works: A Step-by-Step Flow

Let's walk through what happens when you run the application and navigate to the "AI Insights" page:

1.  **You run `streamlit run app.py`:**
    *   Streamlit starts a web server and loads `app.py`.
    *   The `main()` function in `app.py` is called.

2.  **Configuration is loaded:**
    *   `Config` class in `config/config.py` reads your `.env` file and loads API keys.
    *   `Config.validate()` checks if required keys (Supabase, OpenAI) are set. If not, an error is displayed.

3.  **Sidebar is rendered:**
    *   `render_sidebar()` from `src/ui/sidebar.py` is called.
    *   You see the navigation menu, filters, and options.
    *   You select "AI Insights" from the navigation menu.

4.  **AI Insights page is rendered:**
    *   `render_insights()` from `src/ui/insights.py` is called.
    *   The page displays tabs for "Conversational AI", "Prescriptive Analysis", "Predictive Models", etc.

5.  **You ask a question in Conversational AI:**
    *   You type: "Why do I lose more on high volatility days?"
    *   When you click "Analyze", the application:
        *   Fetches your trades from Supabase using `get_supabase_client().get_trades()`.
        *   Fetches your journals using `get_supabase_client().get_journals()`.
        *   Prepares context data (win rate, profit factor, recent emotions, etc.).
        *   Calls `NLPProcessor.generate_conversational_response()` from `src/analysis/nlp_processor.py`.
        *   This function sends your question and context to OpenAI GPT-4o-mini.
        *   OpenAI returns an AI-generated response.
        *   The response is displayed on the page.

## Common Issues and How to Debug Them

### Issue 1: "Missing required configuration" Error

**Symptom:** When you run the app, you see an error message saying "Missing required configuration: SUPABASE_URL, OPENAI_API_KEY".

**Cause:** Your `.env` file is not set up correctly or is missing required API keys.

**Solution:**

1.  Check that you have a `.env` file in the root directory of the project (same folder as `app.py`).
2.  Open `.env` and ensure it has the required keys:
    ```ini
    SUPABASE_URL=your_supabase_project_url
    SUPABASE_KEY=your_supabase_anon_key
    OPENAI_API_KEY=your_openai_api_key
    ```
3.  Replace `your_supabase_project_url`, etc., with your actual API keys.
4.  Restart the Streamlit application.

### Issue 2: "No data available" or Empty Charts

**Symptom:** The dashboard shows "0" for all metrics, or charts display "No data available".

**Cause:** There is no data in your Supabase database yet.

**Solution:**

1.  Go to your Supabase project dashboard.
2.  Navigate to the SQL Editor.
3.  Run the sample data `INSERT` statements from `docs/database_schema.sql` (see the commented section at the bottom).
4.  Refresh the Streamlit app.

### Issue 3: API Connection Errors (TopStep, Databento, OpenAI)

**Symptom:** You see errors like "TopStep API connection test failed" or "Error fetching OHLCV data".

**Cause:** Your API keys are incorrect, expired, or the API service is down.

**Solution:**

1.  **Check API Keys:** Verify that the API keys in your `.env` file are correct.
2.  **Check API Status:** Visit the status pages for TopStep, Databento, and OpenAI to see if there are any outages.
3.  **Check Rate Limits:** Ensure you haven't exceeded the free tier limits for these services.
4.  **Test Manually:** Try making a simple API request using `curl` or Postman to verify that the API is working.

### Issue 4: Streamlit App Crashes or Freezes

**Symptom:** The app stops responding or crashes with an error.

**Cause:** This could be due to a bug in the code, a missing dependency, or an issue with data processing.

**Solution:**

1.  **Check the Terminal:** Look at the terminal where you ran `streamlit run app.py`. Error messages and stack traces will appear there.
2.  **Read the Error Message:** The error message usually tells you which file and line number caused the issue.
3.  **Common Errors:**
    *   **`ModuleNotFoundError`:** You're missing a Python package. Run `pip install <package_name>`.
    *   **`KeyError`:** You're trying to access a dictionary key that doesn't exist. Check your data structure.
    *   **`TypeError`:** You're passing the wrong type of data to a function. Check function signatures.
4.  **Restart the App:** Sometimes, simply restarting the Streamlit app (`Ctrl+C` in terminal, then `streamlit run app.py`) can resolve issues.

## Debugging Tips

1.  **Use `print()` Statements:**
    *   Add `print("Debug: variable_name =", variable_name)` in your code to see what values variables have at different points.
    *   These print statements will appear in your terminal.

2.  **Use Streamlit's `st.write()`:**
    *   In your UI files, use `st.write(variable_name)` to display variable values directly in the app.
    *   This is helpful for debugging data structures like dictionaries and DataFrames.

3.  **Check Logs:**
    *   The application uses Python's `logging` module. Check the terminal for log messages (INFO, WARNING, ERROR).

4.  **Start Small:**
    *   If you're making changes, test them incrementally. Don't change multiple files at once.
    *   Test each change before moving on to the next.

5.  **Use AI Assistants:**
    *   If you're stuck, copy the error message and paste it into ChatGPT, Claude, or Grok AI. They can often help you understand the error and suggest solutions.

## Next Steps

1.  **Explore the Code:** Open each file in `src/` and read through the comments. Try to understand what each function does.
2.  **Make Small Changes:** Try changing some text in the UI files (e.g., `src/ui/dashboard.py`) and see how it affects the app.
3.  **Add Sample Data:** Populate your Supabase database with sample data and see how the app displays it.
4.  **Experiment with Features:** Try using different filters, asking different questions to the AI, and exploring all the pages.

## Resources for Learning

*   **Streamlit Documentation:** [https://docs.streamlit.io/](https://docs.streamlit.io/)
*   **Python Basics:** [https://www.python.org/about/gettingstarted/](https://www.python.org/about/gettingstarted/)
*   **Supabase Documentation:** [https://supabase.com/docs](https://supabase.com/docs)
*   **Plotly Documentation:** [https://plotly.com/python/](https://plotly.com/python/)

Good luck, and don't hesitate to experiment! The best way to learn is by doing.
