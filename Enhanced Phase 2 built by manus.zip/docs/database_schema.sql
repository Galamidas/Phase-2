-- ============================================
-- Phase 2 AI Analysis App - Supabase Schema
-- ============================================
-- This SQL script creates all necessary tables for the application.
-- Run this in your Supabase SQL Editor to set up the database.

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- Users Table
-- ============================================
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email TEXT UNIQUE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    subscription_tier TEXT DEFAULT 'free', -- free, basic, premium
    topstep_api_key TEXT, -- Encrypted in production
    databento_api_key TEXT, -- Encrypted in production
    preferences JSONB DEFAULT '{}'::jsonb
);

-- ============================================
-- Journals Table
-- ============================================
CREATE TABLE IF NOT EXISTS journals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    symbol TEXT, -- MGC, MES, M2K
    entry_type TEXT, -- voice, text
    content TEXT NOT NULL, -- Journal entry content
    voice_transcript TEXT, -- Transcribed voice note
    emotional_state TEXT, -- FOMO, revenge, calm, confident, etc.
    plan_adherence_score INTEGER CHECK (plan_adherence_score >= 1 AND plan_adherence_score <= 10),
    market_context JSONB, -- {atr: 2.5, session: 'london', volatility: 'high'}
    position_size DECIMAL,
    entry_price DECIMAL,
    exit_price DECIMAL,
    tags TEXT[], -- Array of tags like ['FOMO-entry', 'high-vol-breach']
    auto_generated_tags TEXT[], -- AI-generated tags
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index for faster queries
CREATE INDEX IF NOT EXISTS idx_journals_user_timestamp ON journals(user_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_journals_symbol ON journals(symbol);
CREATE INDEX IF NOT EXISTS idx_journals_tags ON journals USING GIN(tags);

-- ============================================
-- Trades Table
-- ============================================
CREATE TABLE IF NOT EXISTS trades (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    external_trade_id TEXT, -- ID from TopStep API
    symbol TEXT NOT NULL, -- MGC, MES, M2K
    direction TEXT NOT NULL, -- long, short
    entry_time TIMESTAMP WITH TIME ZONE NOT NULL,
    exit_time TIMESTAMP WITH TIME ZONE,
    entry_price DECIMAL NOT NULL,
    exit_price DECIMAL,
    position_size DECIMAL NOT NULL,
    pnl DECIMAL, -- Profit/Loss
    pnl_percent DECIMAL, -- P&L as percentage
    commission DECIMAL DEFAULT 0,
    slippage DECIMAL DEFAULT 0,
    mfe DECIMAL, -- Maximum Favorable Excursion
    mae DECIMAL, -- Maximum Adverse Excursion
    hold_time_minutes INTEGER,
    risk_amount DECIMAL,
    reward_amount DECIMAL,
    risk_reward_ratio DECIMAL,
    stop_loss DECIMAL,
    take_profit DECIMAL,
    status TEXT DEFAULT 'open', -- open, closed
    tags TEXT[], -- Tags associated with this trade
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index for faster queries
CREATE INDEX IF NOT EXISTS idx_trades_user_entry_time ON trades(user_id, entry_time DESC);
CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol);
CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status);

-- ============================================
-- Market Data Table
-- ============================================
CREATE TABLE IF NOT EXISTS market_data (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    symbol TEXT NOT NULL,
    timeframe TEXT NOT NULL, -- 1m, 5m, 15m, 30m, 1h, 4h, 1d
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    open DECIMAL NOT NULL,
    high DECIMAL NOT NULL,
    low DECIMAL NOT NULL,
    close DECIMAL NOT NULL,
    volume BIGINT,
    atr DECIMAL, -- Average True Range (volatility indicator)
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(symbol, timeframe, timestamp)
);

-- Index for faster queries
CREATE INDEX IF NOT EXISTS idx_market_data_symbol_timeframe ON market_data(symbol, timeframe, timestamp DESC);

-- ============================================
-- Tags Table
-- ============================================
CREATE TABLE IF NOT EXISTS tags (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    tag TEXT NOT NULL,
    category TEXT, -- emotional, technical, rule-breach, etc.
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, tag)
);

-- Index for faster queries
CREATE INDEX IF NOT EXISTS idx_tags_user ON tags(user_id);

-- ============================================
-- Discord Messages Table (Optional)
-- ============================================
CREATE TABLE IF NOT EXISTS discord_messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    discord_user_id TEXT NOT NULL,
    channel_id TEXT NOT NULL,
    message_id TEXT UNIQUE NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    content TEXT NOT NULL,
    sentiment TEXT, -- positive, negative, neutral
    sentiment_score DECIMAL, -- -1.0 to 1.0
    extracted_symbols TEXT[], -- Symbols mentioned in message
    tags TEXT[], -- Auto-generated tags
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index for faster queries
CREATE INDEX IF NOT EXISTS idx_discord_messages_user ON discord_messages(user_id, timestamp DESC);

-- ============================================
-- AI Insights Table
-- ============================================
CREATE TABLE IF NOT EXISTS ai_insights (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    insight_type TEXT NOT NULL, -- prescriptive, predictive, pattern
    priority TEXT DEFAULT 'medium', -- low, medium, high
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    data_sources TEXT[], -- Sources used to generate insight
    recommendations JSONB, -- Structured recommendations
    confidence_score DECIMAL, -- 0.0 to 1.0
    is_read BOOLEAN DEFAULT FALSE,
    is_applied BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE
);

-- Index for faster queries
CREATE INDEX IF NOT EXISTS idx_ai_insights_user ON ai_insights(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ai_insights_priority ON ai_insights(priority, is_read);

-- ============================================
-- Row Level Security (RLS) Policies
-- ============================================
-- Enable RLS on all tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE journals ENABLE ROW LEVEL SECURITY;
ALTER TABLE trades ENABLE ROW LEVEL SECURITY;
ALTER TABLE market_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE discord_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_insights ENABLE ROW LEVEL SECURITY;

-- Users can only see their own data
CREATE POLICY users_select_own ON users FOR SELECT USING (auth.uid() = id);
CREATE POLICY users_update_own ON users FOR UPDATE USING (auth.uid() = id);

CREATE POLICY journals_select_own ON journals FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY journals_insert_own ON journals FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY journals_update_own ON journals FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY journals_delete_own ON journals FOR DELETE USING (auth.uid() = user_id);

CREATE POLICY trades_select_own ON trades FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY trades_insert_own ON trades FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY trades_update_own ON trades FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY trades_delete_own ON trades FOR DELETE USING (auth.uid() = user_id);

-- Market data is public (all users can read)
CREATE POLICY market_data_select_all ON market_data FOR SELECT USING (true);

CREATE POLICY tags_select_own ON tags FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY tags_insert_own ON tags FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY discord_messages_select_own ON discord_messages FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY discord_messages_insert_own ON discord_messages FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY ai_insights_select_own ON ai_insights FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY ai_insights_update_own ON ai_insights FOR UPDATE USING (auth.uid() = user_id);

-- ============================================
-- Functions and Triggers
-- ============================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_journals_updated_at BEFORE UPDATE ON journals
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_trades_updated_at BEFORE UPDATE ON trades
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- Sample Data (Optional - for testing)
-- ============================================

-- Uncomment to insert sample data for testing
/*
INSERT INTO users (id, email, subscription_tier) VALUES
    ('00000000-0000-0000-0000-000000000001', 'test@example.com', 'free');

INSERT INTO journals (user_id, timestamp, symbol, content, emotional_state, plan_adherence_score, tags) VALUES
    ('00000000-0000-0000-0000-000000000001', NOW() - INTERVAL '1 day', 'MES', 'Felt FOMO on this trade, entered too early', 'FOMO', 4, ARRAY['FOMO-entry', 'early-entry']),
    ('00000000-0000-0000-0000-000000000001', NOW() - INTERVAL '2 days', 'MGC', 'Good setup, followed plan perfectly', 'calm', 9, ARRAY['plan-adherence', 'good-setup']);

INSERT INTO trades (user_id, symbol, direction, entry_time, exit_time, entry_price, exit_price, position_size, pnl, status) VALUES
    ('00000000-0000-0000-0000-000000000001', 'MES', 'long', NOW() - INTERVAL '1 day', NOW() - INTERVAL '23 hours', 5000.00, 5015.00, 1, 15.00, 'closed'),
    ('00000000-0000-0000-0000-000000000001', 'MGC', 'short', NOW() - INTERVAL '2 days', NOW() - INTERVAL '47 hours', 2000.00, 1985.00, 1, 15.00, 'closed');
*/
