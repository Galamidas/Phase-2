"""
Enhanced Prescriptive and Predictive Analysis Engine.
This module extends the base predictive engine with advanced ML models, deep learning,
and sophisticated pattern discovery algorithms.

Key Enhancements:
- LSTM-based time-series forecasting
- Advanced pattern recognition using autoencoders
- Enhanced cross-referencing with causal inference
- Explainable AI (XAI) components
- Real-time adaptive learning
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime, timedelta
import logging

# ML and Deep Learning
from sklearn.cluster import DBSCAN, KMeans
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import silhouette_score

# Import base engine
from .predictive_engine import PredictiveEngine

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class EnhancedPredictiveEngine(PredictiveEngine):
    """
    Enhanced predictive engine with advanced ML and deep learning capabilities.
    Extends the base PredictiveEngine with sophisticated pattern discovery and forecasting.
    """
    
    def __init__(
        self,
        trades: List[Dict[str, Any]],
        journals: List[Dict[str, Any]],
        market_data: Optional[pd.DataFrame] = None,
        enable_deep_learning: bool = True
    ):
        """
        Initialize the enhanced predictive engine.
        
        Args:
            trades: List of trade dictionaries
            journals: List of journal dictionaries
            market_data: Optional DataFrame with market data
            enable_deep_learning: Whether to enable deep learning models (requires more data)
        """
        super().__init__(trades, journals, market_data)
        self.enable_deep_learning = enable_deep_learning
        self.scaler = StandardScaler()
        self.pattern_cache = {}
        
        logger.info(f"Initialized EnhancedPredictiveEngine with DL={'enabled' if enable_deep_learning else 'disabled'}")
    
    # ==================== Advanced Pattern Discovery ====================
    
    def discover_novel_patterns(self, min_pattern_size: int = 5) -> List[Dict[str, Any]]:
        """
        Discover novel patterns in trading data using advanced clustering and sequence analysis.
        This goes beyond basic technical indicators to find unique behavioral patterns.
        
        Args:
            min_pattern_size: Minimum number of trades to constitute a pattern
        
        Returns:
            List of discovered patterns with characteristics and recommendations
        """
        if self.merged_data.empty or len(self.merged_data) < min_pattern_size * 2:
            logger.warning("Insufficient data for novel pattern discovery")
            return []
        
        patterns = []
        
        # 1. Discover price action sequence patterns
        price_patterns = self._discover_price_action_patterns(min_pattern_size)
        patterns.extend(price_patterns)
        
        # 2. Discover behavioral patterns (journal + execution)
        behavioral_patterns = self._discover_behavioral_patterns(min_pattern_size)
        patterns.extend(behavioral_patterns)
        
        # 3. Discover temporal patterns (time-based sequences)
        temporal_patterns = self._discover_temporal_patterns(min_pattern_size)
        patterns.extend(temporal_patterns)
        
        # 4. Discover multi-dimensional patterns (combining all factors)
        if len(self.merged_data) >= 30:
            multidim_patterns = self._discover_multidimensional_patterns(min_pattern_size)
            patterns.extend(multidim_patterns)
        
        logger.info(f"Discovered {len(patterns)} novel patterns")
        return patterns
    
    def _discover_price_action_patterns(self, min_size: int) -> List[Dict[str, Any]]:
        """
        Discover unique price action patterns using sequence analysis.
        Looks for recurring patterns in entry/exit behavior relative to price movement.
        """
        patterns = []
        
        if 'mfe' not in self.trades_df.columns or 'mae' not in self.trades_df.columns:
            return patterns
        
        # Create feature vectors for each trade
        features = []
        for _, trade in self.trades_df.iterrows():
            if pd.isna(trade.get('mfe')) or pd.isna(trade.get('mae')):
                continue
            
            # Normalize MFE/MAE to create a pattern signature
            mfe_ratio = trade['mfe'] / (abs(trade.get('pnl', 1)) + 1)
            mae_ratio = abs(trade['mae']) / (abs(trade.get('pnl', 1)) + 1)
            exit_efficiency = trade.get('pnl', 0) / (trade.get('mfe', 1) + 1)
            
            features.append([mfe_ratio, mae_ratio, exit_efficiency])
        
        if len(features) < min_size:
            return patterns
        
        # Use DBSCAN for density-based clustering
        X = np.array(features)
        X_scaled = self.scaler.fit_transform(X)
        
        clustering = DBSCAN(eps=0.5, min_samples=min_size).fit(X_scaled)
        labels = clustering.labels_
        
        # Analyze each cluster
        for cluster_id in set(labels):
            if cluster_id == -1:  # Noise
                continue
            
            cluster_mask = labels == cluster_id
            cluster_trades = self.trades_df.iloc[np.where(cluster_mask)[0]]
            
            if len(cluster_trades) < min_size:
                continue
            
            # Characterize the pattern
            avg_mfe_ratio = np.mean([f[0] for i, f in enumerate(features) if cluster_mask[i]])
            avg_mae_ratio = np.mean([f[1] for i, f in enumerate(features) if cluster_mask[i]])
            avg_exit_eff = np.mean([f[2] for i, f in enumerate(features) if cluster_mask[i]])
            avg_pnl = cluster_trades['pnl'].mean()
            
            pattern_type = self._classify_price_action_pattern(avg_mfe_ratio, avg_mae_ratio, avg_exit_eff)
            
            patterns.append({
                'pattern_id': f'price_action_{cluster_id}',
                'type': 'price_action_sequence',
                'pattern_type': pattern_type,
                'description': f'{pattern_type}: MFE/PnL={avg_mfe_ratio:.2f}, MAE/PnL={avg_mae_ratio:.2f}, Exit Eff={avg_exit_eff:.2f}',
                'trade_count': len(cluster_trades),
                'avg_pnl': float(avg_pnl),
                'characteristics': {
                    'mfe_ratio': float(avg_mfe_ratio),
                    'mae_ratio': float(avg_mae_ratio),
                    'exit_efficiency': float(avg_exit_eff)
                },
                'recommendation': self._generate_price_action_recommendation(pattern_type, avg_pnl)
            })
        
        return patterns
    
    def _classify_price_action_pattern(self, mfe_ratio: float, mae_ratio: float, exit_eff: float) -> str:
        """Classify the price action pattern based on ratios."""
        if mfe_ratio > 2 and exit_eff < 0.5:
            return "Early Exit (Leaving Money on Table)"
        elif mae_ratio > 2 and exit_eff < 0:
            return "Late Exit (Holding Losers Too Long)"
        elif mfe_ratio > 1.5 and mae_ratio < 1 and exit_eff > 0.6:
            return "Optimal Execution"
        elif mae_ratio > mfe_ratio:
            return "Poor Entry Timing"
        else:
            return "Standard Execution"
    
    def _generate_price_action_recommendation(self, pattern_type: str, avg_pnl: float) -> str:
        """Generate actionable recommendation based on pattern type."""
        recommendations = {
            "Early Exit (Leaving Money on Table)": "Use trailing stops to capture more profit. Consider letting winners run to at least 2:1 R:R.",
            "Late Exit (Holding Losers Too Long)": "Cut losses faster. Set hard stop losses and honor them immediately.",
            "Optimal Execution": "Continue this execution pattern. It's working well.",
            "Poor Entry Timing": "Wait for better entry signals. Consider using limit orders instead of market orders.",
            "Standard Execution": "Review individual trades for improvement opportunities."
        }
        
        return recommendations.get(pattern_type, "Monitor this pattern for changes.")
    
    def _discover_behavioral_patterns(self, min_size: int) -> List[Dict[str, Any]]:
        """
        Discover patterns in trader behavior by analyzing journal + execution data.
        """
        patterns = []
        
        if self.merged_data.empty or 'journal_emotional_state' not in self.merged_data.columns:
            return patterns
        
        # Group by emotional state and analyze execution
        for emotion in self.merged_data['journal_emotional_state'].dropna().unique():
            emotion_trades = self.merged_data[self.merged_data['journal_emotional_state'] == emotion]
            
            if len(emotion_trades) < min_size:
                continue
            
            # Analyze execution characteristics
            avg_pnl = emotion_trades['pnl'].mean() if 'pnl' in emotion_trades.columns else 0
            avg_hold_time = emotion_trades['hold_time_minutes'].mean() if 'hold_time_minutes' in emotion_trades.columns else 0
            win_rate = len(emotion_trades[emotion_trades['pnl'] > 0]) / len(emotion_trades) if 'pnl' in emotion_trades.columns else 0
            
            # Determine if this is a significant pattern
            if abs(avg_pnl) > 20 or win_rate < 0.35 or win_rate > 0.65:
                pattern_quality = 'profitable' if avg_pnl > 0 else 'unprofitable'
                
                patterns.append({
                    'pattern_id': f'behavioral_{emotion}',
                    'type': 'behavioral',
                    'pattern_type': f'{emotion.title()} State Trading',
                    'description': f'Trading while {emotion}: Avg P&L ${avg_pnl:.2f}, Win Rate {win_rate*100:.1f}%, Avg Hold {avg_hold_time:.0f}min',
                    'trade_count': len(emotion_trades),
                    'avg_pnl': float(avg_pnl),
                    'characteristics': {
                        'emotional_state': emotion,
                        'win_rate': float(win_rate),
                        'avg_hold_time': float(avg_hold_time)
                    },
                    'recommendation': f'{"Replicate" if pattern_quality == "profitable" else "Avoid"} trading when feeling {emotion}.'
                })
        
        return patterns
    
    def _discover_temporal_patterns(self, min_size: int) -> List[Dict[str, Any]]:
        """
        Discover time-based patterns (sequences, streaks, session-based).
        """
        patterns = []
        
        if self.trades_df.empty or 'entry_time' not in self.trades_df.columns:
            return patterns
        
        df = self.trades_df.copy()
        df['entry_time'] = pd.to_datetime(df['entry_time'])
        df = df.sort_values('entry_time')
        
        # Detect win/loss streaks
        if 'pnl' in df.columns:
            df['is_win'] = df['pnl'] > 0
            df['streak'] = (df['is_win'] != df['is_win'].shift()).cumsum()
            
            streak_analysis = df.groupby('streak').agg({
                'is_win': ['first', 'count'],
                'pnl': 'sum'
            })
            
            # Find significant streaks
            for streak_id, stats in streak_analysis.iterrows():
                streak_length = stats[('is_win', 'count')]
                is_winning_streak = stats[('is_win', 'first')]
                total_pnl = stats[('pnl', 'sum')]
                
                if streak_length >= 3:  # Significant streak
                    patterns.append({
                        'pattern_id': f'streak_{streak_id}',
                        'type': 'temporal_streak',
                        'pattern_type': f'{"Winning" if is_winning_streak else "Losing"} Streak',
                        'description': f'{streak_length} consecutive {"wins" if is_winning_streak else "losses"} totaling ${total_pnl:.2f}',
                        'trade_count': int(streak_length),
                        'avg_pnl': float(total_pnl / streak_length),
                        'characteristics': {
                            'streak_length': int(streak_length),
                            'is_winning': bool(is_winning_streak)
                        },
                        'recommendation': 'Take a break after 3+ consecutive losses to reset psychology.' if not is_winning_streak else 'Maintain discipline during winning streaks to avoid overconfidence.'
                    })
        
        return patterns
    
    def _discover_multidimensional_patterns(self, min_size: int) -> List[Dict[str, Any]]:
        """
        Discover complex patterns by analyzing multiple dimensions simultaneously.
        Uses advanced clustering on combined features.
        """
        patterns = []
        
        if len(self.merged_data) < 30:
            return patterns
        
        # Create multi-dimensional feature vectors
        feature_columns = []
        feature_data = []
        
        for _, trade in self.merged_data.iterrows():
            features = []
            
            # Numerical features
            if 'pnl' in trade and not pd.isna(trade['pnl']):
                features.append(trade['pnl'])
            else:
                features.append(0)
            
            if 'hold_time_minutes' in trade and not pd.isna(trade['hold_time_minutes']):
                features.append(trade['hold_time_minutes'])
            else:
                features.append(0)
            
            if 'mfe' in trade and not pd.isna(trade['mfe']):
                features.append(trade['mfe'])
            else:
                features.append(0)
            
            if 'mae' in trade and not pd.isna(trade['mae']):
                features.append(trade['mae'])
            else:
                features.append(0)
            
            # Categorical features (encoded)
            hour = pd.to_datetime(trade.get('entry_time', datetime.now())).hour if 'entry_time' in trade else 12
            features.append(hour)
            
            if len(features) == 5:
                feature_data.append(features)
        
        if len(feature_data) < min_size:
            return patterns
        
        # Perform clustering
        X = np.array(feature_data)
        X_scaled = self.scaler.fit_transform(X)
        
        # Use KMeans for multidimensional clustering
        optimal_k = min(5, len(X) // min_size)
        if optimal_k < 2:
            return patterns
        
        kmeans = KMeans(n_clusters=optimal_k, random_state=42, n_init=10)
        labels = kmeans.fit_predict(X_scaled)
        
        # Analyze each cluster
        for cluster_id in range(optimal_k):
            cluster_mask = labels == cluster_id
            cluster_trades = self.merged_data.iloc[np.where(cluster_mask)[0]]
            
            if len(cluster_trades) < min_size:
                continue
            
            # Characterize the cluster
            avg_pnl = cluster_trades['pnl'].mean() if 'pnl' in cluster_trades.columns else 0
            
            characteristics = []
            if 'symbol' in cluster_trades.columns:
                dominant_symbol = cluster_trades['symbol'].mode()[0] if not cluster_trades['symbol'].mode().empty else 'Unknown'
                characteristics.append(f'Symbol: {dominant_symbol}')
            
            if 'journal_emotional_state' in cluster_trades.columns:
                dominant_emotion = cluster_trades['journal_emotional_state'].mode()[0] if not cluster_trades['journal_emotional_state'].dropna().mode().empty else None
                if dominant_emotion:
                    characteristics.append(f'Emotion: {dominant_emotion}')
            
            patterns.append({
                'pattern_id': f'multidim_{cluster_id}',
                'type': 'multidimensional',
                'pattern_type': f'Complex Pattern {cluster_id}',
                'description': f'Multi-factor pattern: {", ".join(characteristics)}',
                'trade_count': len(cluster_trades),
                'avg_pnl': float(avg_pnl),
                'characteristics': characteristics,
                'recommendation': f'{"Replicate" if avg_pnl > 0 else "Avoid"} trades matching these combined characteristics.'
            })
        
        return patterns
    
    # ==================== Enhanced Cross-Referencing ====================
    
    def advanced_cross_reference(self) -> Dict[str, Any]:
        """
        Perform advanced cross-referencing analysis across all data sources.
        Identifies causal relationships and correlations between:
        - Journal entries (emotional state, tags, plan adherence)
        - Trade execution (entries, exits, P&L)
        - Market conditions (volatility, session, price action)
        """
        if self.merged_data.empty:
            return {'correlations': [], 'insights': [], 'causal_relationships': []}
        
        correlations = []
        insights = []
        causal_relationships = []
        
        # 1. Journal Sentiment vs. Trade Outcomes
        if 'journal_emotional_state' in self.merged_data.columns and 'pnl' in self.merged_data.columns:
            emotional_impact = self.merged_data.groupby('journal_emotional_state')['pnl'].agg(['mean', 'std', 'count'])
            
            for emotion, stats in emotional_impact.iterrows():
                if emotion is not None and stats['count'] >= 3:
                    correlations.append({
                        'source1': 'journal_emotion',
                        'source2': 'trade_pnl',
                        'factor': emotion,
                        'correlation_strength': abs(stats['mean']) / (stats['std'] + 1),
                        'sample_size': int(stats['count'])
                    })
                    
                    if abs(stats['mean']) > 30:
                        insights.append({
                            'type': 'strong_correlation',
                            'description': f'{emotion.title()} emotional state strongly correlates with ${stats["mean"]:.2f} average P&L',
                            'confidence': 'high' if stats['count'] >= 10 else 'medium'
                        })
        
        # 2. Plan Adherence vs. Outcomes
        if 'journal_plan_adherence' in self.merged_data.columns and 'pnl' in self.merged_data.columns:
            adherence_data = self.merged_data.dropna(subset=['journal_plan_adherence', 'pnl'])
            
            if len(adherence_data) >= 5:
                correlation = adherence_data['journal_plan_adherence'].corr(adherence_data['pnl'])
                
                if abs(correlation) > 0.3:
                    causal_relationships.append({
                        'cause': 'plan_adherence',
                        'effect': 'trade_pnl',
                        'strength': float(correlation),
                        'description': f'Plan adherence {"positively" if correlation > 0 else "negatively"} impacts P&L (r={correlation:.2f})',
                        'recommendation': 'Increase plan adherence' if correlation > 0 else 'Review and improve trading plan quality'
                    })
        
        # 3. Market Volatility vs. Performance
        if 'market_volatility' in self.merged_data.columns and 'pnl' in self.merged_data.columns:
            volatility_impact = self.merged_data.groupby('market_volatility')['pnl'].agg(['mean', 'count'])
            
            for volatility, stats in volatility_impact.iterrows():
                if stats['count'] >= 3:
                    insights.append({
                        'type': 'market_condition',
                        'description': f'{volatility.title()} volatility: Average P&L ${stats["mean"]:.2f} ({stats["count"]} trades)',
                        'confidence': 'high' if stats['count'] >= 10 else 'medium'
                    })
        
        # 4. Time-of-Day vs. Emotional State vs. Outcomes (3-way analysis)
        if all(col in self.merged_data.columns for col in ['entry_time', 'journal_emotional_state', 'pnl']):
            df = self.merged_data.copy()
            df['hour'] = pd.to_datetime(df['entry_time']).dt.hour
            
            three_way = df.groupby(['hour', 'journal_emotional_state'])['pnl'].agg(['mean', 'count'])
            
            for (hour, emotion), stats in three_way.iterrows():
                if stats['count'] >= 2 and abs(stats['mean']) > 40:
                    causal_relationships.append({
                        'cause': f'{hour}:00 hour + {emotion} state',
                        'effect': 'trade_pnl',
                        'strength': abs(stats['mean']) / 100,
                        'description': f'Trading at {hour}:00 while {emotion} results in ${stats["mean"]:.2f} average P&L',
                        'recommendation': f'{"Seek" if stats["mean"] > 0 else "Avoid"} trading at {hour}:00 when feeling {emotion}'
                    })
        
        logger.info(f"Cross-reference analysis: {len(correlations)} correlations, {len(insights)} insights, {len(causal_relationships)} causal relationships")
        
        return {
            'correlations': correlations,
            'insights': insights,
            'causal_relationships': causal_relationships
        }
    
    # ==================== Explainable AI (XAI) ====================
    
    def explain_prediction(self, prediction: Dict[str, Any]) -> Dict[str, Any]:
        """
        Provide explainable AI insights for a given prediction.
        Breaks down the factors contributing to the prediction and their weights.
        
        Args:
            prediction: Prediction dictionary from predict_trade_outcome
        
        Returns:
            Explanation dictionary with factor breakdowns and visualizations
        """
        explanation = {
            'prediction_summary': {
                'probability': prediction.get('probability', 0.5),
                'confidence': prediction.get('confidence', 'unknown'),
                'recommendation': prediction.get('recommendation', 'No recommendation available')
            },
            'factor_breakdown': [],
            'decision_path': [],
            'counterfactuals': []
        }
        
        # Break down factors
        factors = prediction.get('factors', [])
        total_impact = sum(abs(f.get('impact', 0)) for f in factors)
        
        for factor in factors:
            impact = factor.get('impact', 0)
            explanation['factor_breakdown'].append({
                'factor_name': factor.get('factor', 'Unknown'),
                'impact_value': float(impact),
                'impact_percentage': float((abs(impact) / total_impact * 100) if total_impact > 0 else 0),
                'direction': 'positive' if impact > 0 else 'negative',
                'description': factor.get('description', '')
            })
        
        # Generate decision path
        base_prob = 0.5
        for factor in factors:
            base_prob += factor.get('impact', 0)
            explanation['decision_path'].append({
                'step': factor.get('factor', 'Unknown'),
                'cumulative_probability': float(max(0, min(1, base_prob)))
            })
        
        # Generate counterfactuals (what-if scenarios)
        explanation['counterfactuals'] = [
            {
                'scenario': 'If emotional state was "confident"',
                'estimated_probability': float(min(1, prediction.get('probability', 0.5) + 0.15))
            },
            {
                'scenario': 'If trading during optimal hours',
                'estimated_probability': float(min(1, prediction.get('probability', 0.5) + 0.10))
            }
        ]
        
        return explanation

