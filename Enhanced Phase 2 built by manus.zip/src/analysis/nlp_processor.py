"""
NLP processor module for journal analysis and auto-tagging.
Uses OpenAI GPT-4o-mini for extracting tags and sentiment from journal entries.
"""

from openai import OpenAI
from typing import List, Dict, Any, Optional
from config.config import Config
import logging
import json

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class NLPProcessor:
    """
    NLP processor for analyzing journal entries and generating tags.
    """
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize NLP processor with OpenAI client.
        
        Args:
            api_key: OpenAI API key (defaults to Config.OPENAI_API_KEY)
        """
        self.api_key = api_key or Config.OPENAI_API_KEY
        
        if not self.api_key:
            logger.warning("OpenAI API key not configured")
            self.client = None
        else:
            try:
                self.client = OpenAI(api_key=self.api_key)
                logger.info("OpenAI client initialized successfully")
            except Exception as e:
                logger.error(f"Failed to initialize OpenAI client: {e}")
                self.client = None
    
    def extract_tags(self, journal_content: str, max_tags: int = 5) -> List[str]:
        """
        Extract relevant tags from journal content using OpenAI.
        
        Args:
            journal_content: The journal entry text
            max_tags: Maximum number of tags to extract
        
        Returns:
            List of extracted tags
        """
        if not self.client:
            logger.error("OpenAI client not initialized")
            return []
        
        try:
            prompt = f"""Analyze the following trading journal entry and extract {max_tags} relevant tags.
Focus on:
- Emotional states (e.g., FOMO, revenge, calm, confident, anxious)
- Trading behaviors (e.g., early-entry, late-exit, plan-adherence, impulsive)
- Market conditions (e.g., high-vol, low-vol, trending, ranging)
- Rule violations (e.g., position-size-breach, stop-loss-moved, overtrading)
- Specific patterns (e.g., revenge-M2K, FOMO-MGC, high-vol-breach)

Journal entry:
"{journal_content}"

Return ONLY a JSON array of tags, nothing else. Example: ["FOMO-entry", "high-vol", "plan-adherence-low", "emotional-trade", "MES-long"]
"""
            
            response = self.client.chat.completions.create(
                model=Config.OPENAI_MODEL,
                messages=[
                    {"role": "system", "content": "You are an expert trading psychology analyst. Extract concise, relevant tags from trading journal entries."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=Config.MAX_OPENAI_TOKENS,
                temperature=0.3  # Lower temperature for more consistent tagging
            )
            
            # Parse the response
            tags_text = response.choices[0].message.content.strip()
            
            # Try to parse as JSON
            try:
                tags = json.loads(tags_text)
                if isinstance(tags, list):
                    logger.info(f"Extracted {len(tags)} tags from journal")
                    return tags[:max_tags]
            except json.JSONDecodeError:
                # Fallback: extract tags from text
                tags = [tag.strip().strip('"\'') for tag in tags_text.split(',')]
                return [tag for tag in tags if tag][:max_tags]
        
        except Exception as e:
            logger.error(f"Error extracting tags: {e}")
            return []
    
    def analyze_sentiment(self, journal_content: str) -> Dict[str, Any]:
        """
        Analyze sentiment and emotional state from journal content.
        
        Args:
            journal_content: The journal entry text
        
        Returns:
            Dictionary with sentiment analysis results
        """
        if not self.client:
            logger.error("OpenAI client not initialized")
            return {"sentiment": "neutral", "confidence": 0.0, "emotions": []}
        
        try:
            prompt = f"""Analyze the emotional state and sentiment of this trading journal entry.

Journal entry:
"{journal_content}"

Provide your analysis in JSON format with:
- sentiment: "positive", "negative", or "neutral"
- confidence: 0.0 to 1.0
- emotions: list of detected emotions (e.g., ["confident", "anxious", "FOMO"])
- emotional_state: primary emotional state (e.g., "calm", "FOMO", "revenge", "confident", "anxious")

Example response:
{{
  "sentiment": "negative",
  "confidence": 0.85,
  "emotions": ["anxious", "FOMO", "regret"],
  "emotional_state": "FOMO"
}}
"""
            
            response = self.client.chat.completions.create(
                model=Config.OPENAI_MODEL,
                messages=[
                    {"role": "system", "content": "You are an expert in trading psychology and sentiment analysis."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=Config.MAX_OPENAI_TOKENS,
                temperature=0.3
            )
            
            # Parse the response
            result_text = response.choices[0].message.content.strip()
            
            try:
                result = json.loads(result_text)
                logger.info(f"Sentiment analysis: {result.get('emotional_state')}")
                return result
            except json.JSONDecodeError:
                logger.error("Failed to parse sentiment analysis response")
                return {"sentiment": "neutral", "confidence": 0.0, "emotions": [], "emotional_state": "unknown"}
        
        except Exception as e:
            logger.error(f"Error analyzing sentiment: {e}")
            return {"sentiment": "neutral", "confidence": 0.0, "emotions": [], "emotional_state": "unknown"}
    
    def extract_trading_details(self, journal_content: str) -> Dict[str, Any]:
        """
        Extract trading-specific details from journal content.
        
        Args:
            journal_content: The journal entry text
        
        Returns:
            Dictionary with extracted trading details
        """
        if not self.client:
            logger.error("OpenAI client not initialized")
            return {}
        
        try:
            prompt = f"""Extract trading-specific details from this journal entry.

Journal entry:
"{journal_content}"

Provide extracted information in JSON format with:
- symbol: trading symbol mentioned (MGC, MES, M2K, or null)
- direction: trade direction (long, short, or null)
- entry_rationale: brief summary of entry reasoning
- concerns: list of concerns or worries mentioned
- plan_adherence: estimated adherence to plan (1-10, or null)
- market_conditions: mentioned market conditions

Example response:
{{
  "symbol": "MES",
  "direction": "long",
  "entry_rationale": "Breakout above resistance",
  "concerns": ["High volatility", "Late entry"],
  "plan_adherence": 6,
  "market_conditions": "High volatility, trending"
}}
"""
            
            response = self.client.chat.completions.create(
                model=Config.OPENAI_MODEL,
                messages=[
                    {"role": "system", "content": "You are an expert trading analyst. Extract structured information from trading journals."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=Config.MAX_OPENAI_TOKENS,
                temperature=0.3
            )
            
            # Parse the response
            result_text = response.choices[0].message.content.strip()
            
            try:
                result = json.loads(result_text)
                logger.info("Extracted trading details from journal")
                return result
            except json.JSONDecodeError:
                logger.error("Failed to parse trading details response")
                return {}
        
        except Exception as e:
            logger.error(f"Error extracting trading details: {e}")
            return {}
    
    def process_journal_entry(self, journal_content: str) -> Dict[str, Any]:
        """
        Comprehensive processing of a journal entry.
        Combines tag extraction, sentiment analysis, and detail extraction.
        
        Args:
            journal_content: The journal entry text
        
        Returns:
            Dictionary with all processed information
        """
        logger.info("Processing journal entry with NLP")
        
        # Extract tags
        tags = self.extract_tags(journal_content)
        
        # Analyze sentiment
        sentiment = self.analyze_sentiment(journal_content)
        
        # Extract trading details
        details = self.extract_trading_details(journal_content)
        
        return {
            "tags": tags,
            "sentiment": sentiment.get("sentiment"),
            "emotional_state": sentiment.get("emotional_state"),
            "emotions": sentiment.get("emotions", []),
            "confidence": sentiment.get("confidence", 0.0),
            "symbol": details.get("symbol"),
            "direction": details.get("direction"),
            "entry_rationale": details.get("entry_rationale"),
            "concerns": details.get("concerns", []),
            "plan_adherence": details.get("plan_adherence"),
            "market_conditions": details.get("market_conditions")
        }
    
    def generate_conversational_response(
        self,
        user_query: str,
        context: Dict[str, Any]
    ) -> str:
        """
        Generate conversational AI response for user queries about their trading.
        
        Args:
            user_query: User's question
            context: Context including trades, journals, and analysis data
        
        Returns:
            AI-generated response
        """
        if not self.client:
            logger.error("OpenAI client not initialized")
            return "AI assistant is not available. Please configure OpenAI API key."
        
        try:
            # Build context prompt
            context_prompt = f"""You are an expert trading coach and analyst. Answer the user's question based on their trading data.

Context:
- Total trades: {context.get('total_trades', 0)}
- Win rate: {context.get('win_rate', 0)}%
- Profit factor: {context.get('profit_factor', 0)}
- Recent emotional states: {', '.join(context.get('recent_emotions', []))}
- Common tags: {', '.join(context.get('common_tags', []))}

Additional context:
{json.dumps(context.get('additional_context', {}), indent=2)}

User question: {user_query}

Provide a detailed, actionable response with specific insights and recommendations based on the data.
"""
            
            response = self.client.chat.completions.create(
                model=Config.OPENAI_MODEL,
                messages=[
                    {"role": "system", "content": "You are an expert trading coach specializing in futures trading and trading psychology. Provide actionable, data-driven insights."},
                    {"role": "user", "content": context_prompt}
                ],
                max_tokens=1000,  # Allow longer responses for conversational AI
                temperature=0.7  # Higher temperature for more natural conversation
            )
            
            return response.choices[0].message.content.strip()
        
        except Exception as e:
            logger.error(f"Error generating conversational response: {e}")
            return f"I encountered an error processing your question: {str(e)}"

# Global instance
_nlp_processor = None

def get_nlp_processor(api_key: Optional[str] = None) -> NLPProcessor:
    """
    Get or create the global NLP processor instance.
    
    Args:
        api_key: Optional API key to override config
    
    Returns:
        NLPProcessor instance
    """
    global _nlp_processor
    if _nlp_processor is None or api_key:
        _nlp_processor = NLPProcessor(api_key=api_key)
    return _nlp_processor
