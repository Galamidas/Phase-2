"""
Prescriptive and Predictive Analysis Engine.
This is the core module for advanced AI-driven insights, pattern discovery, and predictions.
Includes ML models, cross-referencing, and real-time recommendations.
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime, timedelta
from sklearn.cluster import KMeans, DBSCAN
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class PredictiveEngine:
    """
    Advanced predictive and prescriptive analysis engine.
    Combines rule-based logic with ML models for comprehensive insights.
    """
    
    def __init__(
        self,
        trades: List[Dict[str, Any]],
        journals: List[Dict[str, Any]],
        market_data: Optional[pd.DataFrame] = None
    ):
        """
        Initialize the predictive engine with all available data.
        
        Args:
            trades: List of trade dictionaries
            journals: List of journal dictionaries
            market_data: Optional DataFrame with market data
        """
        self.trades_df = pd.DataFrame(trades) if trades else pd.DataFrame()
        self.journals_df = pd.DataFrame(journals) if journals else pd.DataFrame()
        self.market_data = market_data if market_data is not None else pd.DataFrame()
        
        # Prepare merged dataset for cross-referencing
        self.merged_data = self._merge_data_sources()
        
        logger.info(f"Initialized PredictiveEngine with {len(self.trades_df)} trades and {len(self.journals_df)} journals")
    
    # ==================== Data Preparation ====================
    
    def _merge_data_sources(self) -> pd.DataFrame:
        """
        Merge trades, journals, and market data for cross-referencing analysis.
        
        Returns:
            Merged DataFrame with all data sources
        """
        if self.trades_df.empty:
            return pd.DataFrame()
        
        merged = self.trades_df.copy()
        
        # Merge journals by matching timestamps
        if not self.journals_df.empty:
            merged = self._merge_journals_with_trades(merged)
        
        # Add market context
        if not self.market_data.empty:
            merged = self._add_market_context(merged)
        
        logger.info(f"Merged data: {len(merged)} rows with {len(merged.columns)} columns")
        return merged
    
    def _merge_journals_with_trades(self, trades: pd.DataFrame) -> pd.DataFrame:
        """Match journal entries to trades by timestamp and symbol."""
        if self.journals_df.empty:
            return trades
        
        # Convert timestamps
        trades['entry_time'] = pd.to_datetime(trades['entry_time'])
        journals = self.journals_df.copy()
        journals['timestamp'] = pd.to_datetime(journals['timestamp'])
        
        # For each trade, find the closest journal entry within 1 hour
        matched_journals = []
        for _, trade in trades.iterrows():
            time_diff = abs(journals['timestamp'] - trade['entry_time'])
            within_hour = time_diff < timedelta(hours=1)
            
            if within_hour.any():
                closest_idx = time_diff[within_hour].idxmin()
                closest_journal = journals.loc[closest_idx]
                matched_journals.append({
                    'journal_emotional_state': closest_journal.get('emotional_state'),
                    'journal_tags': closest_journal.get('tags', []),
                    'journal_plan_adherence': closest_journal.get('plan_adherence_score'),
                    'journal_content': closest_journal.get('content', '')[:200]
                })
            else:
                matched_journals.append({
                    'journal_emotional_state': None,
                    'journal_tags': [],
                    'journal_plan_adherence': None,
                    'journal_content': ''
                })
        
        # Add journal data to trades
        for key in matched_journals[0].keys():
            trades[key] = [j[key] for j in matched_journals]
        
        return trades
    
    def _add_market_context(self, trades: pd.DataFrame) -> pd.DataFrame:
        """Add market context (volatility, session) to trades."""
        if self.market_data.empty:
            return trades
        
        # Add market volatility and session info
        # This would use the databento_client's get_market_context method
        # For now, add placeholder columns
        trades['market_volatility'] = 'medium'
        trades['market_session'] = 'new_york'
        
        return trades
    
    # ==================== Prescriptive Analysis ====================
    
    def generate_prescriptive_recommendations(self) -> List[Dict[str, Any]]:
        """
        Generate real-time prescriptive recommendations based on patterns and analysis.
        
        Returns:
            List of recommendation dictionaries
        """
        recommendations = []
        
        # Analyze emotional patterns
        emotional_recs = self._analyze_emotional_patterns()
        recommendations.extend(emotional_recs)
        
        # Analyze timing patterns
        timing_recs = self._analyze_timing_patterns()
        recommendations.extend(timing_recs)
        
        # Analyze volatility patterns
        volatility_recs = self._analyze_volatility_patterns()
        recommendations.extend(volatility_recs)
        
        # Analyze execution patterns
        execution_recs = self._analyze_execution_patterns()
        recommendations.extend(execution_recs)
        
        # Sort by priority
        priority_order = {'high': 0, 'medium': 1, 'low': 2}
        recommendations.sort(key=lambda x: priority_order.get(x['priority'], 3))
        
        logger.info(f"Generated {len(recommendations)} prescriptive recommendations")
        return recommendations
    
    def _analyze_emotional_patterns(self) -> List[Dict[str, Any]]:
        """Analyze emotional state patterns and generate recommendations."""
        recommendations = []
        
        if self.merged_data.empty or 'journal_emotional_state' not in self.merged_data.columns:
            return recommendations
        
        # Group by emotional state
        emotional_performance = self.merged_data.groupby('journal_emotional_state').agg({
            'pnl': ['mean', 'count', 'sum']
        })
        
        for emotion, stats in emotional_performance.iterrows():
            if emotion is None or stats[('pnl', 'count')] < 3:
                continue
            
            avg_pnl = stats[('pnl', 'mean')]
            trade_count = stats[('pnl', 'count')]
            
            if avg_pnl < -20 and trade_count >= 3:
                recommendations.append({
                    'priority': 'high',
                    'category': 'Emotional Pattern',
                    'title': f'Poor Performance During {emotion.upper()} State',
                    'message': f'Your average P&L is ${avg_pnl:.2f} when experiencing {emotion}. Consider taking a break or avoiding trades when feeling {emotion}.',
                    'data_source': f'{trade_count} trades analyzed',
                    'actionable_steps': [
                        f'Set an alert to pause trading when feeling {emotion}',
                        'Take a 15-minute break before entering trades',
                        'Review your trading plan and ensure emotional control'
                    ],
                    'expected_impact': f'Potential to improve P&L by ${abs(avg_pnl * trade_count):.2f}'
                })
        
        return recommendations
    
    def _analyze_timing_patterns(self) -> List[Dict[str, Any]]:
        """Analyze time-of-day and day-of-week patterns."""
        recommendations = []
        
        if self.trades_df.empty or 'entry_time' not in self.trades_df.columns:
            return recommendations
        
        df = self.trades_df.copy()
        df['entry_time'] = pd.to_datetime(df['entry_time'])
        df['hour'] = df['entry_time'].dt.hour
        df['day_of_week'] = df['entry_time'].dt.dayofweek
        
        # Analyze by hour
        hourly_performance = df.groupby('hour').agg({
            'pnl': ['mean', 'count']
        })
        
        for hour, stats in hourly_performance.iterrows():
            if stats[('pnl', 'count')] >= 3 and stats[('pnl', 'mean')] < -30:
                recommendations.append({
                    'priority': 'medium',
                    'category': 'Timing Pattern',
                    'title': f'Consistent Losses During {hour}:00 Hour',
                    'message': f'You lose an average of ${abs(stats[("pnl", "mean")]):.2f} per trade during the {hour}:00 hour. Consider avoiding this time slot.',
                    'data_source': f'{stats[("pnl", "count")]} trades analyzed',
                    'actionable_steps': [
                        f'Avoid trading between {hour}:00 and {hour+1}:00',
                        'Analyze what market conditions occur during this hour',
                        'Focus on more profitable time slots'
                    ],
                    'expected_impact': 'Avoid average loss of ${:.2f} per trade'.format(abs(stats[('pnl', 'mean')]))
                })
        
        return recommendations
    
    def _analyze_volatility_patterns(self) -> List[Dict[str, Any]]:
        """Analyze performance in different volatility conditions."""
        recommendations = []
        
        if self.merged_data.empty or 'market_volatility' not in self.merged_data.columns:
            return recommendations
        
        volatility_performance = self.merged_data.groupby('market_volatility').agg({
            'pnl': ['mean', 'count']
        })
        
        for volatility, stats in volatility_performance.iterrows():
            if stats[('pnl', 'count')] >= 5 and stats[('pnl', 'mean')] < -25:
                recommendations.append({
                    'priority': 'high',
                    'category': 'Market Conditions',
                    'title': f'Underperformance in {volatility.title()} Volatility',
                    'message': f'Your win rate drops significantly during {volatility} volatility conditions. Consider reducing position size or avoiding trades.',
                    'data_source': f'{stats[("pnl", "count")]} trades analyzed',
                    'actionable_steps': [
                        f'Reduce position size by 50% during {volatility} volatility',
                        'Use wider stop losses to account for volatility',
                        'Wait for volatility to normalize before entering'
                    ],
                    'expected_impact': 'Potential to reduce losses by 40-60%'
                })
        
        return recommendations
    
    def _analyze_execution_patterns(self) -> List[Dict[str, Any]]:
        """Analyze execution patterns (MFE/MAE, hold times, etc.)."""
        recommendations = []
        
        if self.trades_df.empty:
            return recommendations
        
        # Analyze exit efficiency
        if 'mfe' in self.trades_df.columns and 'pnl' in self.trades_df.columns:
            winners = self.trades_df[self.trades_df['pnl'] > 0]
            if not winners.empty and 'mfe' in winners.columns:
                exit_efficiency = (winners['pnl'] / winners['mfe']).mean() * 100
                
                if exit_efficiency < 60:  # Capturing less than 60% of MFE
                    recommendations.append({
                        'priority': 'medium',
                        'category': 'Execution',
                        'title': 'Exiting Winning Trades Too Early',
                        'message': f'You are only capturing {exit_efficiency:.1f}% of your maximum favorable excursion. Consider using trailing stops to capture more profit.',
                        'data_source': f'{len(winners)} winning trades analyzed',
                        'actionable_steps': [
                            'Implement a trailing stop at 1.5R',
                            'Let winners run to at least 2:1 R:R',
                            'Avoid taking profit at predetermined targets'
                        ],
                        'expected_impact': f'Potential to increase average win by {(100-exit_efficiency):.0f}%'
                    })
        
        # Analyze hold time patterns
        if 'hold_time_minutes' in self.trades_df.columns and 'pnl' in self.trades_df.columns:
            correlation = self.trades_df['hold_time_minutes'].corr(self.trades_df['pnl'])
            
            if correlation < -0.3:  # Negative correlation
                recommendations.append({
                    'priority': 'low',
                    'category': 'Execution',
                    'title': 'Longer Hold Times Lead to Worse Outcomes',
                    'message': 'Your trades perform worse the longer you hold them. Consider taking profits earlier or using time-based exits.',
                    'data_source': f'{len(self.trades_df)} trades analyzed',
                    'actionable_steps': [
                        'Set a maximum hold time of 4 hours',
                        'Exit at first sign of reversal',
                        'Use time-based profit targets'
                    ],
                    'expected_impact': 'Reduce average loss per trade'
                })
        
        return recommendations
    
    # ==================== Predictive Analysis ====================
    
    def predict_trade_outcome(
        self,
        symbol: str,
        direction: str,
        current_volatility: float,
        emotional_state: str,
        time_of_day: int
    ) -> Dict[str, Any]:
        """
        Predict the probability of success for a potential trade.
        
        Args:
            symbol: Trading symbol
            direction: Trade direction (long/short)
            current_volatility: Current ATR/volatility
            emotional_state: Current emotional state
            time_of_day: Hour of day (0-23)
        
        Returns:
            Prediction dictionary with probability and recommendation
        """
        if self.merged_data.empty or len(self.merged_data) < 20:
            return {
                'probability': 0.5,
                'confidence': 'low',
                'recommendation': 'Insufficient data for prediction',
                'factors': []
            }
        
        # Use rule-based prediction for now (can be upgraded to ML model)
        factors = []
        base_probability = 0.5
        
        # Factor 1: Symbol performance
        symbol_trades = self.trades_df[self.trades_df['symbol'] == symbol]
        if not symbol_trades.empty:
            symbol_win_rate = len(symbol_trades[symbol_trades['pnl'] > 0]) / len(symbol_trades)
            base_probability = symbol_win_rate
            factors.append({
                'factor': 'Symbol Performance',
                'impact': symbol_win_rate - 0.5,
                'description': f'{symbol} historical win rate: {symbol_win_rate*100:.1f}%'
            })
        
        # Factor 2: Emotional state
        if not self.merged_data.empty and 'journal_emotional_state' in self.merged_data.columns:
            emotional_trades = self.merged_data[self.merged_data['journal_emotional_state'] == emotional_state]
            if not emotional_trades.empty:
                emotional_win_rate = len(emotional_trades[emotional_trades['pnl'] > 0]) / len(emotional_trades)
                emotional_impact = (emotional_win_rate - 0.5) * 0.3
                base_probability += emotional_impact
                factors.append({
                    'factor': 'Emotional State',
                    'impact': emotional_impact,
                    'description': f'{emotional_state} state win rate: {emotional_win_rate*100:.1f}%'
                })
        
        # Factor 3: Time of day
        time_trades = self.trades_df[pd.to_datetime(self.trades_df['entry_time']).dt.hour == time_of_day]
        if not time_trades.empty:
            time_win_rate = len(time_trades[time_trades['pnl'] > 0]) / len(time_trades)
            time_impact = (time_win_rate - 0.5) * 0.2
            base_probability += time_impact
            factors.append({
                'factor': 'Time of Day',
                'impact': time_impact,
                'description': f'{time_of_day}:00 hour win rate: {time_win_rate*100:.1f}%'
            })
        
        # Clamp probability between 0 and 1
        final_probability = max(0.0, min(1.0, base_probability))
        
        # Determine confidence based on sample size
        total_relevant_trades = len(symbol_trades) + len(time_trades)
        if total_relevant_trades > 50:
            confidence = 'high'
        elif total_relevant_trades > 20:
            confidence = 'medium'
        else:
            confidence = 'low'
        
        # Generate recommendation
        if final_probability > 0.65:
            recommendation = 'STRONG GO - Favorable conditions'
        elif final_probability > 0.55:
            recommendation = 'GO - Slightly favorable conditions'
        elif final_probability > 0.45:
            recommendation = 'NEUTRAL - No clear edge'
        elif final_probability > 0.35:
            recommendation = 'CAUTION - Slightly unfavorable conditions'
        else:
            recommendation = 'AVOID - Unfavorable conditions'
        
        return {
            'probability': final_probability,
            'confidence': confidence,
            'recommendation': recommendation,
            'factors': factors,
            'sample_size': total_relevant_trades
        }
    
    # ==================== Pattern Discovery ====================
    
    def discover_novel_patterns(self) -> List[Dict[str, Any]]:
        """
        Discover novel patterns using unsupervised learning and cross-referencing.
        This finds patterns that haven't been explicitly programmed.
        
        Returns:
            List of discovered pattern dictionaries
        """
        discovered_patterns = []
        
        if self.merged_data.empty or len(self.merged_data) < 10:
            logger.warning("Insufficient data for pattern discovery")
            return discovered_patterns
        
        # Prepare features for clustering
        features = self._prepare_features_for_clustering()
        
        if features.empty:
            return discovered_patterns
        
        # Apply clustering to find groups of similar trades
        clusters = self._apply_clustering(features)
        
        # Analyze each cluster
        for cluster_id in clusters['cluster'].unique():
            cluster_trades = self.merged_data[clusters['cluster'] == cluster_id]
            pattern = self._analyze_cluster(cluster_id, cluster_trades)
            
            if pattern:
                discovered_patterns.append(pattern)
        
        logger.info(f"Discovered {len(discovered_patterns)} novel patterns")
        return discovered_patterns
    
    def _prepare_features_for_clustering(self) -> pd.DataFrame:
        """Prepare numerical features for clustering analysis."""
        if self.merged_data.empty:
            return pd.DataFrame()
        
        features = pd.DataFrame()
        
        # Numerical features
        if 'pnl' in self.merged_data.columns:
            features['pnl'] = self.merged_data['pnl']
        if 'hold_time_minutes' in self.merged_data.columns:
            features['hold_time_minutes'] = self.merged_data['hold_time_minutes']
        if 'risk_reward_ratio' in self.merged_data.columns:
            features['risk_reward_ratio'] = self.merged_data['risk_reward_ratio']
        
        # Encode categorical features
        if 'symbol' in self.merged_data.columns:
            features['symbol_encoded'] = pd.Categorical(self.merged_data['symbol']).codes
        if 'direction' in self.merged_data.columns:
            features['direction_encoded'] = pd.Categorical(self.merged_data['direction']).codes
        
        # Time features
        if 'entry_time' in self.merged_data.columns:
            entry_times = pd.to_datetime(self.merged_data['entry_time'])
            features['hour'] = entry_times.dt.hour
            features['day_of_week'] = entry_times.dt.dayofweek
        
        # Drop NaN values
        features = features.dropna()
        
        return features
    
    def _apply_clustering(self, features: pd.DataFrame) -> pd.DataFrame:
        """Apply K-Means clustering to find trade groups."""
        if features.empty or len(features) < 5:
            return pd.DataFrame({'cluster': []})
        
        # Standardize features
        scaler = StandardScaler()
        features_scaled = scaler.fit_transform(features)
        
        # Determine optimal number of clusters (3-5)
        n_clusters = min(5, max(3, len(features) // 10))
        
        # Apply K-Means
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        clusters = kmeans.fit_predict(features_scaled)
        
        result = features.copy()
        result['cluster'] = clusters
        
        return result
    
    def _analyze_cluster(self, cluster_id: int, cluster_trades: pd.DataFrame) -> Optional[Dict[str, Any]]:
        """Analyze a cluster to identify patterns."""
        if cluster_trades.empty or len(cluster_trades) < 3:
            return None
        
        # Calculate cluster statistics
        avg_pnl = cluster_trades['pnl'].mean() if 'pnl' in cluster_trades.columns else 0
        trade_count = len(cluster_trades)
        
        # Identify distinguishing characteristics
        characteristics = []
        
        # Check symbol concentration
        if 'symbol' in cluster_trades.columns:
            symbol_dist = cluster_trades['symbol'].value_counts()
            dominant_symbol = symbol_dist.index[0]
            if symbol_dist.iloc[0] / trade_count > 0.6:
                characteristics.append(f'Primarily {dominant_symbol} trades')
        
        # Check time patterns
        if 'entry_time' in cluster_trades.columns:
            hours = pd.to_datetime(cluster_trades['entry_time']).dt.hour
            dominant_hour = hours.mode()[0] if not hours.mode().empty else None
            if dominant_hour is not None:
                characteristics.append(f'Mostly during {dominant_hour}:00 hour')
        
        # Check emotional patterns
        if 'journal_emotional_state' in cluster_trades.columns:
            emotions = cluster_trades['journal_emotional_state'].dropna()
            if not emotions.empty:
                dominant_emotion = emotions.mode()[0] if not emotions.mode().empty else None
                if dominant_emotion:
                    characteristics.append(f'Associated with {dominant_emotion} emotional state')
        
        if not characteristics:
            return None
        
        # Generate pattern description
        pattern_type = 'profitable' if avg_pnl > 0 else 'losing'
        
        return {
            'pattern_id': f'cluster_{cluster_id}',
            'type': 'discovered_pattern',
            'pattern_type': pattern_type,
            'description': f'Pattern {cluster_id}: {", ".join(characteristics)}',
            'avg_pnl': float(avg_pnl),
            'trade_count': int(trade_count),
            'characteristics': characteristics,
            'recommendation': f'{"Replicate" if avg_pnl > 0 else "Avoid"} trades with these characteristics'
        }
    
    # ==================== Cross-Reference Analysis ====================
    
    def cross_reference_analysis(
        self,
        source1: str,
        source2: str
    ) -> Dict[str, Any]:
        """
        Perform cross-reference analysis between two data sources.
        
        Args:
            source1: First data source (e.g., 'journals', 'trades', 'market_data')
            source2: Second data source
        
        Returns:
            Dictionary with correlation and insights
        """
        if self.merged_data.empty:
            return {'correlation': 0, 'insights': []}
        
        correlations = []
        insights = []
        
        # Example: Journal sentiment vs. Trade outcomes
        if source1 == 'journals' and source2 == 'trades':
            if 'journal_emotional_state' in self.merged_data.columns and 'pnl' in self.merged_data.columns:
                emotional_impact = self.merged_data.groupby('journal_emotional_state')['pnl'].mean()
                
                for emotion, avg_pnl in emotional_impact.items():
                    if emotion is not None:
                        insights.append({
                            'insight': f'{emotion.title()} emotional state correlates with ${avg_pnl:.2f} average P&L',
                            'strength': 'strong' if abs(avg_pnl) > 50 else 'moderate'
                        })
        
        return {
            'source1': source1,
            'source2': source2,
            'correlations': correlations,
            'insights': insights
        }
