"""
Trade analytics module with advanced mathematical models.
Implements MFE/MAE, R:R ratios, expectancy, profit factor, and prop firm compliance.
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime, timedelta
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TradeAnalytics:
    """
    Advanced trade analytics with mathematical models.
    """
    
    def __init__(self, trades: List[Dict[str, Any]]):
        """
        Initialize trade analytics with trade data.
        
        Args:
            trades: List of trade dictionaries
        """
        self.trades_df = pd.DataFrame(trades) if trades else pd.DataFrame()
        logger.info(f"Initialized TradeAnalytics with {len(self.trades_df)} trades")
    
    # ==================== Basic Metrics ====================
    
    def calculate_win_rate(self, symbol: Optional[str] = None) -> float:
        """Calculate win rate (percentage of profitable trades)."""
        df = self._filter_by_symbol(symbol)
        if df.empty or 'pnl' not in df.columns:
            return 0.0
        
        winning_trades = len(df[df['pnl'] > 0])
        total_trades = len(df[df['pnl'].notna()])
        
        return (winning_trades / total_trades * 100) if total_trades > 0 else 0.0
    
    def calculate_profit_factor(self, symbol: Optional[str] = None) -> float:
        """Calculate profit factor (gross profit / gross loss)."""
        df = self._filter_by_symbol(symbol)
        if df.empty or 'pnl' not in df.columns:
            return 0.0
        
        gross_profit = df[df['pnl'] > 0]['pnl'].sum()
        gross_loss = abs(df[df['pnl'] < 0]['pnl'].sum())
        
        return (gross_profit / gross_loss) if gross_loss > 0 else 0.0
    
    def calculate_expectancy(self, symbol: Optional[str] = None) -> float:
        """Calculate expectancy (average P&L per trade)."""
        df = self._filter_by_symbol(symbol)
        if df.empty or 'pnl' not in df.columns:
            return 0.0
        
        return df['pnl'].mean()
    
    def calculate_sharpe_ratio(self, symbol: Optional[str] = None, risk_free_rate: float = 0.0) -> float:
        """Calculate Sharpe ratio (risk-adjusted return)."""
        df = self._filter_by_symbol(symbol)
        if df.empty or 'pnl' not in df.columns:
            return 0.0
        
        returns = df['pnl']
        excess_returns = returns - risk_free_rate
        
        if returns.std() == 0:
            return 0.0
        
        return excess_returns.mean() / returns.std()
    
    # ==================== MFE/MAE Analysis ====================
    
    def calculate_mfe_mae(self) -> Dict[str, Any]:
        """
        Calculate Maximum Favorable Excursion (MFE) and Maximum Adverse Excursion (MAE).
        
        Returns:
            Dictionary with MFE/MAE statistics
        """
        df = self.trades_df
        if df.empty or 'mfe' not in df.columns or 'mae' not in df.columns:
            return {"avg_mfe": 0, "avg_mae": 0, "mfe_mae_ratio": 0}
        
        avg_mfe = df['mfe'].mean()
        avg_mae = df['mae'].mean()
        mfe_mae_ratio = (avg_mfe / abs(avg_mae)) if avg_mae != 0 else 0
        
        # Separate by winners and losers
        winners = df[df['pnl'] > 0]
        losers = df[df['pnl'] < 0]
        
        return {
            "avg_mfe": avg_mfe,
            "avg_mae": avg_mae,
            "mfe_mae_ratio": mfe_mae_ratio,
            "winners_avg_mfe": winners['mfe'].mean() if not winners.empty else 0,
            "winners_avg_mae": winners['mae'].mean() if not winners.empty else 0,
            "losers_avg_mfe": losers['mfe'].mean() if not losers.empty else 0,
            "losers_avg_mae": losers['mae'].mean() if not losers.empty else 0,
            "exit_efficiency": self._calculate_exit_efficiency()
        }
    
    def _calculate_exit_efficiency(self) -> float:
        """
        Calculate exit efficiency (how much of MFE was captured).
        
        Returns:
            Exit efficiency as percentage
        """
        df = self.trades_df
        if df.empty or 'mfe' not in df.columns or 'pnl' not in df.columns:
            return 0.0
        
        winners = df[df['pnl'] > 0]
        if winners.empty:
            return 0.0
        
        # Exit efficiency = actual profit / maximum possible profit (MFE)
        efficiency = (winners['pnl'] / winners['mfe']).mean() * 100
        return efficiency if not np.isnan(efficiency) else 0.0
    
    # ==================== Risk/Reward Analysis ====================
    
    def calculate_risk_reward_stats(self) -> Dict[str, Any]:
        """
        Calculate risk/reward ratio statistics.
        
        Returns:
            Dictionary with R:R statistics
        """
        df = self.trades_df
        if df.empty or 'risk_reward_ratio' not in df.columns:
            return {"avg_rr": 0, "median_rr": 0, "winning_rr": 0, "losing_rr": 0}
        
        avg_rr = df['risk_reward_ratio'].mean()
        median_rr = df['risk_reward_ratio'].median()
        
        winners = df[df['pnl'] > 0]
        losers = df[df['pnl'] < 0]
        
        winning_rr = winners['risk_reward_ratio'].mean() if not winners.empty else 0
        losing_rr = losers['risk_reward_ratio'].mean() if not losers.empty else 0
        
        return {
            "avg_rr": avg_rr,
            "median_rr": median_rr,
            "winning_rr": winning_rr,
            "losing_rr": losing_rr,
            "rr_distribution": self._get_rr_distribution()
        }
    
    def _get_rr_distribution(self) -> Dict[str, int]:
        """Get distribution of R:R ratios."""
        df = self.trades_df
        if df.empty or 'risk_reward_ratio' not in df.columns:
            return {}
        
        bins = [0, 1, 2, 3, 5, float('inf')]
        labels = ['<1:1', '1:1-2:1', '2:1-3:1', '3:1-5:1', '>5:1']
        
        df['rr_bin'] = pd.cut(df['risk_reward_ratio'], bins=bins, labels=labels)
        distribution = df['rr_bin'].value_counts().to_dict()
        
        return {str(k): int(v) for k, v in distribution.items()}
    
    # ==================== Hold Time Analysis ====================
    
    def calculate_hold_time_stats(self) -> Dict[str, Any]:
        """
        Calculate hold time statistics.
        
        Returns:
            Dictionary with hold time statistics
        """
        df = self.trades_df
        if df.empty or 'hold_time_minutes' not in df.columns:
            return {"avg_hold_time": 0, "median_hold_time": 0, "winners_hold_time": 0, "losers_hold_time": 0}
        
        avg_hold_time = df['hold_time_minutes'].mean()
        median_hold_time = df['hold_time_minutes'].median()
        
        winners = df[df['pnl'] > 0]
        losers = df[df['pnl'] < 0]
        
        winners_hold_time = winners['hold_time_minutes'].mean() if not winners.empty else 0
        losers_hold_time = losers['hold_time_minutes'].mean() if not losers.empty else 0
        
        return {
            "avg_hold_time": avg_hold_time,
            "median_hold_time": median_hold_time,
            "winners_hold_time": winners_hold_time,
            "losers_hold_time": losers_hold_time,
            "hold_time_correlation": self._calculate_hold_time_correlation()
        }
    
    def _calculate_hold_time_correlation(self) -> float:
        """Calculate correlation between hold time and profitability."""
        df = self.trades_df
        if df.empty or 'hold_time_minutes' not in df.columns or 'pnl' not in df.columns:
            return 0.0
        
        correlation = df['hold_time_minutes'].corr(df['pnl'])
        return correlation if not np.isnan(correlation) else 0.0
    
    # ==================== Streak Analysis ====================
    
    def calculate_streaks(self) -> Dict[str, Any]:
        """
        Calculate win/loss streak statistics.
        
        Returns:
            Dictionary with streak statistics
        """
        df = self.trades_df.sort_values('entry_time')
        if df.empty or 'pnl' not in df.columns:
            return {"longest_win_streak": 0, "longest_loss_streak": 0, "current_streak": 0}
        
        # Create win/loss indicator
        df['is_win'] = df['pnl'] > 0
        
        # Calculate streaks
        df['streak_id'] = (df['is_win'] != df['is_win'].shift()).cumsum()
        streaks = df.groupby('streak_id').agg({
            'is_win': ['first', 'count']
        })
        
        win_streaks = streaks[streaks[('is_win', 'first')] == True][('is_win', 'count')]
        loss_streaks = streaks[streaks[('is_win', 'first')] == False][('is_win', 'count')]
        
        longest_win_streak = int(win_streaks.max()) if not win_streaks.empty else 0
        longest_loss_streak = int(loss_streaks.max()) if not loss_streaks.empty else 0
        
        # Current streak
        current_streak_type = df.iloc[-1]['is_win'] if not df.empty else None
        current_streak_length = int(streaks.iloc[-1][('is_win', 'count')]) if not streaks.empty else 0
        
        return {
            "longest_win_streak": longest_win_streak,
            "longest_loss_streak": longest_loss_streak,
            "current_streak": current_streak_length if current_streak_type else -current_streak_length,
            "avg_win_streak": win_streaks.mean() if not win_streaks.empty else 0,
            "avg_loss_streak": loss_streaks.mean() if not loss_streaks.empty else 0
        }
    
    # ==================== Prop Firm Compliance ====================
    
    def calculate_prop_compliance(
        self,
        max_daily_loss: float = 1000,
        max_total_drawdown: float = 2000,
        max_position_size: int = 5
    ) -> Dict[str, Any]:
        """
        Calculate prop firm compliance metrics.
        
        Args:
            max_daily_loss: Maximum daily loss limit
            max_total_drawdown: Maximum total drawdown limit
            max_position_size: Maximum position size limit
        
        Returns:
            Dictionary with compliance metrics
        """
        df = self.trades_df
        if df.empty:
            return {"compliant": True, "violations": []}
        
        violations = []
        
        # Check daily loss limits
        if 'entry_time' in df.columns and 'pnl' in df.columns:
            df['date'] = pd.to_datetime(df['entry_time']).dt.date
            daily_pnl = df.groupby('date')['pnl'].sum()
            
            daily_loss_violations = daily_pnl[daily_pnl < -max_daily_loss]
            for date, loss in daily_loss_violations.items():
                violations.append({
                    "type": "daily_loss_limit",
                    "date": str(date),
                    "loss": float(loss),
                    "limit": max_daily_loss
                })
        
        # Check total drawdown
        if 'pnl' in df.columns:
            cumulative_pnl = df['pnl'].cumsum()
            running_max = cumulative_pnl.cummax()
            drawdown = cumulative_pnl - running_max
            max_drawdown = abs(drawdown.min())
            
            if max_drawdown > max_total_drawdown:
                violations.append({
                    "type": "total_drawdown",
                    "drawdown": float(max_drawdown),
                    "limit": max_total_drawdown
                })
        
        # Check position size violations
        if 'position_size' in df.columns:
            position_violations = df[df['position_size'] > max_position_size]
            for _, trade in position_violations.iterrows():
                violations.append({
                    "type": "position_size",
                    "trade_id": trade.get('id'),
                    "position_size": float(trade['position_size']),
                    "limit": max_position_size
                })
        
        return {
            "compliant": len(violations) == 0,
            "violations": violations,
            "violation_count": len(violations),
            "current_drawdown": float(max_drawdown) if 'pnl' in df.columns else 0,
            "drawdown_percentage": (max_drawdown / max_total_drawdown * 100) if 'pnl' in df.columns else 0
        }
    
    # ==================== Pattern Detection ====================
    
    def detect_patterns(self, journals: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        """
        Detect patterns in trading behavior.
        
        Args:
            journals: Optional list of journal entries for correlation
        
        Returns:
            Dictionary with detected patterns
        """
        patterns = []
        
        # Time-of-day patterns
        time_patterns = self._detect_time_patterns()
        if time_patterns:
            patterns.extend(time_patterns)
        
        # Symbol-specific patterns
        symbol_patterns = self._detect_symbol_patterns()
        if symbol_patterns:
            patterns.extend(symbol_patterns)
        
        # Emotional patterns (if journals provided)
        if journals:
            emotional_patterns = self._detect_emotional_patterns(journals)
            if emotional_patterns:
                patterns.extend(emotional_patterns)
        
        return {
            "patterns": patterns,
            "pattern_count": len(patterns)
        }
    
    def _detect_time_patterns(self) -> List[Dict[str, Any]]:
        """Detect time-of-day trading patterns."""
        df = self.trades_df
        if df.empty or 'entry_time' not in df.columns or 'pnl' not in df.columns:
            return []
        
        df['hour'] = pd.to_datetime(df['entry_time']).dt.hour
        hourly_performance = df.groupby('hour').agg({
            'pnl': ['mean', 'count']
        })
        
        patterns = []
        for hour, row in hourly_performance.iterrows():
            avg_pnl = row[('pnl', 'mean')]
            trade_count = row[('pnl', 'count')]
            
            if trade_count >= 3:  # Minimum sample size
                if avg_pnl < -50:  # Significant losses
                    patterns.append({
                        "type": "time_pattern",
                        "description": f"Consistently losing during hour {hour}:00",
                        "avg_pnl": float(avg_pnl),
                        "trade_count": int(trade_count),
                        "recommendation": f"Avoid trading during {hour}:00 hour"
                    })
        
        return patterns
    
    def _detect_symbol_patterns(self) -> List[Dict[str, Any]]:
        """Detect symbol-specific patterns."""
        df = self.trades_df
        if df.empty or 'symbol' not in df.columns or 'pnl' not in df.columns:
            return []
        
        symbol_performance = df.groupby('symbol').agg({
            'pnl': ['mean', 'sum', 'count']
        })
        
        patterns = []
        for symbol, row in symbol_performance.iterrows():
            avg_pnl = row[('pnl', 'mean')]
            total_pnl = row[('pnl', 'sum')]
            trade_count = row[('pnl', 'count')]
            
            if trade_count >= 5 and avg_pnl < -20:
                patterns.append({
                    "type": "symbol_pattern",
                    "description": f"Underperforming on {symbol}",
                    "symbol": symbol,
                    "avg_pnl": float(avg_pnl),
                    "total_pnl": float(total_pnl),
                    "trade_count": int(trade_count),
                    "recommendation": f"Review strategy for {symbol} or reduce exposure"
                })
        
        return patterns
    
    def _detect_emotional_patterns(self, journals: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Detect emotional patterns correlated with trade outcomes."""
        # This would require matching journals to trades by timestamp
        # Implementation would cross-reference journal emotional states with trade outcomes
        return []
    
    # ==================== Utility Methods ====================
    
    def _filter_by_symbol(self, symbol: Optional[str]) -> pd.DataFrame:
        """Filter trades by symbol."""
        if symbol and not self.trades_df.empty and 'symbol' in self.trades_df.columns:
            return self.trades_df[self.trades_df['symbol'] == symbol]
        return self.trades_df
    
    def get_summary_stats(self) -> Dict[str, Any]:
        """
        Get comprehensive summary statistics.
        
        Returns:
            Dictionary with all key metrics
        """
        return {
            "total_trades": len(self.trades_df),
            "win_rate": self.calculate_win_rate(),
            "profit_factor": self.calculate_profit_factor(),
            "expectancy": self.calculate_expectancy(),
            "sharpe_ratio": self.calculate_sharpe_ratio(),
            "mfe_mae": self.calculate_mfe_mae(),
            "risk_reward": self.calculate_risk_reward_stats(),
            "hold_time": self.calculate_hold_time_stats(),
            "streaks": self.calculate_streaks(),
            "prop_compliance": self.calculate_prop_compliance()
        }


    # ==================== Consolidated Summary ====================

    def get_performance_summary(self) -> Dict[str, Any]:
        """
        Generates a consolidated performance summary of all trades.

        Returns:
            Dictionary with key performance indicators.
        """
        if self.trades_df.empty:
            return {
                "total_trades": 0,
                "total_pnl": 0.0,
                "win_rate": 0.0,
                "profit_factor": 0.0,
                "expectancy": 0.0,
                "avg_rr": 0.0,
                "longest_win_streak": 0,
                "longest_loss_streak": 0,
                "current_streak": 0,
                "max_drawdown": 0.0,
                "compliant": True,
                "violation_count": 0
            }

        total_trades = len(self.trades_df)
        total_pnl = self.trades_df["pnl"].sum()

        win_rate = self.calculate_win_rate()
        profit_factor = self.calculate_profit_factor()
        expectancy = self.calculate_expectancy()

        # MFE/MAE and R:R might require additional columns to be present in trades_df
        # For now, we'll assume they are or handle their absence gracefully
        mfe_mae_stats = self.calculate_mfe_mae()
        rr_stats = self.calculate_risk_reward_stats()
        streak_stats = self.calculate_streaks()
        prop_compliance = self.calculate_prop_compliance()

        return {
            "total_trades": total_trades,
            "total_pnl": float(total_pnl),
            "win_rate": float(win_rate),
            "profit_factor": float(profit_factor),
            "expectancy": float(expectancy),
            "avg_rr": float(rr_stats.get("avg_rr", 0.0)),
            "longest_win_streak": int(streak_stats.get("longest_win_streak", 0)),
            "longest_loss_streak": int(streak_stats.get("longest_loss_streak", 0)),
            "current_streak": int(streak_stats.get("current_streak", 0)),
            "max_drawdown": float(prop_compliance.get("current_drawdown", 0.0)),
            "compliant": bool(prop_compliance.get("compliant", True)),
            "violation_count": int(prop_compliance.get("violation_count", 0))
        }

