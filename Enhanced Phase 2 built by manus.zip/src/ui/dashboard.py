
"""
Dashboard UI component - Overview of trading performance and key metrics.
"""

import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
from typing import List, Dict, Any

from src.analysis.trade_analytics import TradeAnalytics

def render_page(trade_analytics: TradeAnalytics, trades: List[Dict[str, Any]], journals: List[Dict[str, Any]]):
    """
    Render the main dashboard with key performance metrics and overview.
    """
    
    st.header("📈 Trading Dashboard")
    st.markdown("Overview of your trading performance and key metrics")
    
    # Get performance summary
    performance_summary = trade_analytics.get_performance_summary()
    
    # Key metrics row
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="Total Trades",
            value=performance_summary["total_trades"],
            delta="" # No delta for now
        )
    
    with col2:
        st.metric(
            label="Win Rate",
            value=f"{performance_summary['win_rate']:.2f}%",
            delta="" # No delta for now
        )
    
    with col3:
        st.metric(
            label="Profit Factor",
            value=f"{performance_summary['profit_factor']:.2f}",
            delta="" # No delta for now
        )
    
    with col4:
        st.metric(
            label="Total P&L",
            value=f"${performance_summary['total_pnl']:.2f}",
            delta="" # No delta for now
        )
    
    st.divider()
    
    # Recent activity section
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("📊 Recent Trading Activity")
        if trades:
            trades_df = pd.DataFrame(trades)
            st.dataframe(trades_df.head(5).set_index("entry_time"), use_container_width=True)
        else:
            st.info("No trading data available yet. Load sample data or connect your data sources.")
        
    with col2:
        st.subheader("📝 Recent Journal Entries")
        if journals:
            journals_df = pd.DataFrame(journals)
            st.dataframe(journals_df.head(5).set_index("timestamp"), use_container_width=True)
        else:
            st.info("No journal entries available yet. Load sample data or sync your Phase 1 PWA data.")
    
    st.divider()
    
    # Performance charts section
    st.subheader("📉 Performance Overview")
    
    tab1, tab2, tab3 = st.tabs(["Equity Curve", "Win/Loss Distribution", "Symbol Performance"])
    
    with tab1:
        st.info("Equity curve will be displayed here once trade data is available.")
    
    with tab2:
        st.info("Win/Loss distribution chart will be displayed here once trade data is available.")
    
    with tab3:
        st.info("Symbol-specific performance metrics will be displayed here once trade data is available.")
    
    st.divider()
    
    # Quick actions
    st.subheader("⚡ Quick Actions")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("🔄 Sync Journal Data", use_container_width=True):
            st.info("Journal data sync will be implemented in the next phase.")
    
    with col2:
        if st.button("📥 Import Trades", use_container_width=True):
            st.info("Trade import from TopStep will be implemented in the next phase.")
    
    with col3:
        if st.button("🤖 Generate AI Insights", use_container_width=True):
            st.info("AI insights generation will be implemented in the next phase.")

