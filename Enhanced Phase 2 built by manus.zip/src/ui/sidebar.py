
"""
Sidebar UI component for navigation and filtering.
"""

import streamlit as st
from datetime import datetime, timedelta
from config.config import Config

def render_sidebar(config_class: type[Config]):
    """
    Render the sidebar with navigation menu and filter options.
    Returns the selected page name.
    """
    
    with st.sidebar:
        st.header("🧭 Navigation")
        
        # Page selection
        page = st.radio(
            "Select Page",
            ["Dashboard", "Trade Analysis", "Interactive Charts", "AI Insights"],
            index=0
        )
        
        st.divider()
        
        # Filters section
        st.header("🔍 Filters")
        
        # Symbol selection
        selected_symbol = st.selectbox(
            "Trading Symbol",
            config_class.SUPPORTED_SYMBOLS,
            index=config_class.SUPPORTED_SYMBOLS.index(st.session_state.get("selected_symbol", "MES"))
        )
        st.session_state.selected_symbol = selected_symbol
        
        # Date range selection
        date_range_options = {
            "Last 7 Days": 7,
            "Last 30 Days": 30,
            "Last 90 Days": 90,
            "Last 180 Days": 180,
            "Last Year": 365,
            "All Time": None
        }
        
        date_range_label = st.selectbox(
            "Date Range",
            list(date_range_options.keys()),
            index=list(date_range_options.keys()).index(st.session_state.get("date_range_label", "Last 30 Days"))
        )
        st.session_state.date_range_label = date_range_label
        st.session_state.date_range = date_range_options[date_range_label]
        
        # Custom date range
        use_custom_dates = st.checkbox("Use Custom Date Range")
        if use_custom_dates:
            col1, col2 = st.columns(2)
            with col1:
                start_date = st.date_input(
                    "Start Date",
                    value=st.session_state.get("custom_start_date", datetime.now() - timedelta(days=30))
                )
            with col2:
                end_date = st.date_input(
                    "End Date",
                    value=st.session_state.get("custom_end_date", datetime.now())
                )
            st.session_state.custom_start_date = start_date
            st.session_state.custom_end_date = end_date
        
        st.divider()
        
        # Additional filters
        st.header("⚙️ Options")
        
        # Show only profitable trades
        show_profitable_only = st.checkbox("Show Profitable Trades Only", value=st.session_state.get("show_profitable_only", False))
        st.session_state.show_profitable_only = show_profitable_only
        
        # Show only trades with journals
        show_with_journals_only = st.checkbox("Show Trades with Journals Only", value=st.session_state.get("show_with_journals_only", False))
        st.session_state.show_with_journals_only = show_with_journals_only
        
        # Tag filters (will be populated dynamically from database)
        st.subheader("Filter by Tags")
        tag_filter = st.multiselect(
            "Select Tags",
            ["FOMO-entry", "high-vol-breach", "revenge-M2K", "plan-adherence", "emotional-trade"],
            default=st.session_state.get("tag_filter", [])
        )
        st.session_state.tag_filter = tag_filter
        
        st.divider()
        
        # Data refresh button
        if st.button("🔄 Refresh Data", use_container_width=True):
            st.cache_data.clear()
            st.rerun()
        
        # About section
        with st.expander("ℹ️ About"):
            st.markdown("""
            **Phase 2 AI Analysis App**
            
            This application provides advanced AI-powered analysis for reflexive trading journals,
            integrating real-time market data, trade history, and prescriptive/predictive insights.
            
            **Features:**
            - Real-time data synchronization
            - NLP-powered journal tagging
            - Advanced trade analytics
            - Interactive charting
            - AI-driven insights and predictions
            """)
    
    return page

