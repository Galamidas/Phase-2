
"""
Interactive Charts UI component - MT4/MT5-style charting with trade and journal overlays.
"""

import streamlit as st
import plotly.graph_objects as go
import pandas as pd
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional

def render_page(trades: List[Dict[str, Any]], journals: List[Dict[str, Any]], market_data: Dict[str, pd.DataFrame]):
    """
    Render interactive charts with trade entries/exits and journal annotations.
    """
    
    st.header("📊 Interactive Charts")
    st.markdown("MT4/MT5-style interactive charts with trade and journal overlays")
    
    # Chart controls
    col1, col2, col3 = st.columns(3)
    
    available_symbols = list(market_data.keys()) if market_data else [st.session_state.get("selected_symbol", "MES")]
    if not available_symbols:
        st.info("No market data available to display charts. Load sample data or connect Databento.")
        return

    with col1:
        chart_symbol = st.selectbox(
            "Symbol",
            available_symbols,
            index=available_symbols.index(st.session_state.get("selected_symbol", available_symbols[0])) if st.session_state.get("selected_symbol") in available_symbols else 0
        )
    
    with col2:
        timeframe = st.selectbox(
            "Timeframe",
            ["1m", "5m", "15m", "30m", "1h", "4h", "1d"],
            index=5  # Default to 4h
        )
    
    with col3:
        chart_type = st.selectbox(
            "Chart Type",
            ["Candlestick", "Line", "OHLC"],
            index=0
        )
    
    # Chart options
    with st.expander("🎨 Chart Options"):
        col1, col2, col3 = st.columns(3)
        
        with col1:
            show_trades = st.checkbox("Show Trade Entries/Exits", value=True)
            show_journals = st.checkbox("Show Journal Annotations", value=True)
        
        with col2:
            show_volume = st.checkbox("Show Volume", value=True)
            show_indicators = st.checkbox("Show Technical Indicators", value=False)
        
        with col3:
            show_atr = st.checkbox("Show ATR (Volatility)", value=False)
            show_sessions = st.checkbox("Show Trading Sessions", value=False)
    
    st.divider()
    
    # Generate chart
    st.subheader(f"{chart_symbol} - {timeframe} Chart")
    
    if chart_symbol not in market_data or market_data[chart_symbol].empty:
        st.info(f"No market data available for {chart_symbol} at the selected timeframe.")
        return

    df_market = market_data[chart_symbol]
    
    # Filter trades and journals for the selected symbol
    filtered_trades = [t for t in trades if t.get("symbol") == chart_symbol]
    filtered_journals = [j for j in journals if j.get("symbol") == chart_symbol]

    fig = create_interactive_chart(df_market, chart_type, filtered_trades, filtered_journals, show_trades, show_journals, show_volume)
    st.plotly_chart(fig, use_container_width=True)
    
    st.divider()
    
    # Trade and journal details below chart
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📍 Trades on Chart")
        if show_trades and filtered_trades:
            st.dataframe(pd.DataFrame(filtered_trades).set_index("entry_time"), use_container_width=True)
        else:
            st.info("No trades to display or 'Show Trade Entries/Exits' is unchecked.")
    
    with col2:
        st.subheader("📝 Journal Entries on Chart")
        if show_journals and filtered_journals:
            st.dataframe(pd.DataFrame(filtered_journals).set_index("timestamp"), use_container_width=True)
        else:
            st.info("No journal entries to display or 'Show Journal Annotations' is unchecked.")

def create_interactive_chart(
    df_market: pd.DataFrame,
    chart_type: str,
    trades: List[Dict[str, Any]],
    journals: List[Dict[str, Any]],
    show_trades: bool,
    show_journals: bool,
    show_volume: bool
) -> go.Figure:
    """
    Create an interactive Plotly chart with market data, trade entries/exits, and journal annotations.
    """
    fig = go.Figure()

    # Add main price trace
    if chart_type == "Candlestick":
        fig.add_trace(go.Candlestick(
            x=df_market["timestamp"],
            open=df_market["open"],
            high=df_market["high"],
            low=df_market["low"],
            close=df_market["close"],
            name="Price",
            increasing_line_color='#26a69a', decreasing_line_color='#ef5350'
        ))
    elif chart_type == "Line":
        fig.add_trace(go.Scatter(
            x=df_market["timestamp"],
            y=df_market["close"],
            mode='lines',
            name="Price",
            line=dict(color='blue', width=2)
        ))
    elif chart_type == "OHLC":
        fig.add_trace(go.Ohlc(
            x=df_market["timestamp"],
            open=df_market["open"],
            high=df_market["high"],
            low=df_market["low"],
            close=df_market["close"],
            name="Price"
        ))

    # Add trade entry/exit markers
    if show_trades and trades:
        entry_x = [pd.to_datetime(t["entry_time"]) for t in trades]
        entry_y = [t["entry_price"] for t in trades]
        exit_x = [pd.to_datetime(t["exit_time"]) for t in trades]
        exit_y = [t["exit_price"] for t in trades]

        fig.add_trace(go.Scatter(
            x=entry_x,
            y=entry_y,
            mode='markers',
            marker=dict(symbol='triangle-up', size=10, color='green'),
            name="Trade Entry",
            hoverinfo='text',
            hovertext=[f"Entry: {t['entry_price']}<br>P&L: {t['pnl']}" for t in trades]
        ))
        fig.add_trace(go.Scatter(
            x=exit_x,
            y=exit_y,
            mode='markers',
            marker=dict(symbol='triangle-down', size=10, color='red'),
            name="Trade Exit",
            hoverinfo='text',
            hovertext=[f"Exit: {t['exit_price']}<br>P&L: {t['pnl']}" for t in trades]
        ))

    # Add journal annotations
    if show_journals and journals:
        journal_x = [pd.to_datetime(j["timestamp"]) for j in journals]
        journal_y = [df_market[(df_market["timestamp"] <= ts) & (df_market["timestamp"] >= ts - timedelta(minutes=5))]["close"].iloc[-1] if not df_market[(df_market["timestamp"] <= ts) & (df_market["timestamp"] >= ts - timedelta(minutes=5))].empty else None for ts in journal_x]
        journal_y = [y if y is not None else df_market["close"].mean() for y in journal_y] # Fallback if no close price found

        fig.add_trace(go.Scatter(
            x=journal_x,
            y=journal_y,
            mode='markers',
            marker=dict(symbol='circle', size=12, color='purple', opacity=0.7, line=dict(width=1, color='DarkSlateGrey')),
            name="Journal Entry",
            hoverinfo='text',
            hovertext=[f"Journal: {j['emotional_state']}<br>{j['content'][:100]}..." for j in journals]
        ))

    # Add volume subplot
    if show_volume and "volume" in df_market.columns:
        fig.add_trace(go.Bar(
            x=df_market["timestamp"],
            y=df_market["volume"],
            name="Volume",
            marker_color='rgba(0,0,255,0.5)',
            yaxis='y2'
        ))
        fig.update_layout(yaxis2=dict(title='Volume', overlaying='y', side='right', showgrid=False))

    # Update layout
    fig.update_layout(
        title=f"{df_market['symbol'].iloc[0]} Price Chart",
        xaxis_title="Time",
        yaxis_title="Price",
        height=700,
        xaxis_rangeslider_visible=False,
        hovermode='x unified',
        template='plotly_white'
    )
    
    return fig

