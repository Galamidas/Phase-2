
"""
Trade Analysis UI component - In-depth trade analysis with mathematical models.
"""

import streamlit as st
import pandas as pd
from typing import List, Dict, Any

from src.analysis.trade_analytics import TradeAnalytics

def render_page(trade_analytics: TradeAnalytics, trades: List[Dict[str, Any]], journals: List[Dict[str, Any]]):
    """
    Render the trade analysis page with advanced metrics and models.
    """
    
    st.header("🔬 Trade Analysis")
    st.markdown("In-depth analysis of your trades with advanced mathematical models")
    
    # Analysis type selection
    analysis_type = st.selectbox(
        "Select Analysis Type",
        [
            "Overview",
            "MFE/MAE Analysis",
            "Risk/Reward Ratios",
            "Hold Time Analysis",
            "Win/Loss Streaks",
            "Expectancy & Profit Factor",
            "Prop Firm Compliance",
            "Pattern Detection"
        ]
    )
    
    st.divider()
    
    if analysis_type == "Overview":
        render_analysis_overview(trade_analytics)
    elif analysis_type == "MFE/MAE Analysis":
        render_mfe_mae_analysis(trade_analytics)
    elif analysis_type == "Risk/Reward Ratios":
        render_risk_reward_analysis(trade_analytics)
    elif analysis_type == "Hold Time Analysis":
        render_hold_time_analysis(trade_analytics)
    elif analysis_type == "Win/Loss Streaks":
        render_streak_analysis(trade_analytics)
    elif analysis_type == "Expectancy & Profit Factor":
        render_expectancy_analysis(trade_analytics)
    elif analysis_type == "Prop Firm Compliance":
        render_prop_compliance_analysis(trade_analytics)
    elif analysis_type == "Pattern Detection":
        render_pattern_detection(trade_analytics, journals)

def render_analysis_overview(trade_analytics: TradeAnalytics):
    """
    Render overview of all analysis metrics.
    """
    st.subheader("📊 Analysis Overview")
    summary = trade_analytics.get_performance_summary()
    
    if summary["total_trades"] == 0:
        st.info("No trading data available for analysis. Load sample data or connect your data sources.")
        return

    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Trades", summary["total_trades"])
        st.metric("Win Rate", f"{summary['win_rate']:.2f}%")
        st.metric("Profit Factor", f"{summary['profit_factor']:.2f}")
    with col2:
        st.metric("Total P&L", f"${summary['total_pnl']:.2f}")
        st.metric("Expectancy", f"${summary['expectancy']:.2f}")
        st.metric("Avg R:R", f"{summary['avg_rr']:.2f}")
    with col3:
        st.metric("Longest Win Streak", summary['longest_win_streak'])
        st.metric("Longest Loss Streak", summary['longest_loss_streak'])
        st.metric("Current Streak", summary['current_streak'])
    
    st.markdown("--- ")
    st.subheader("Prop Firm Compliance")
    if summary["compliant"]:
        st.success("✅ Currently compliant with prop firm rules.")
    else:
        st.error(f"❌ {summary['violation_count']} prop firm violation(s) detected.")
        st.write(f"Max Drawdown: ${summary['max_drawdown']:.2f}")

def render_mfe_mae_analysis(trade_analytics: TradeAnalytics):
    """
    Render Maximum Favorable Excursion and Maximum Adverse Excursion analysis.
    """
    st.subheader("📈 MFE/MAE Analysis")
    st.markdown("""
    **Maximum Favorable Excursion (MFE)** and **Maximum Adverse Excursion (MAE)** help you understand:
    - How far trades moved in your favor before closing
    - How far trades moved against you before closing
    - Whether you\'re exiting too early or holding losers too long
    """)
    
    if trade_analytics.trades_df.empty:
        st.info("No trading data available for MFE/MAE analysis.")
        return

    mfe_mae_stats = trade_analytics.calculate_mfe_mae()
    st.write(f"Average MFE: ${mfe_mae_stats['avg_mfe']:.2f}")
    st.write(f"Average MAE: ${mfe_mae_stats['avg_mae']:.2f}")
    st.write(f"MFE/MAE Ratio: {mfe_mae_stats['mfe_mae_ratio']:.2f}")
    st.write(f"Exit Efficiency (Winners): {mfe_mae_stats['exit_efficiency']:.2f}%")

def render_risk_reward_analysis(trade_analytics: TradeAnalytics):
    """
    Render risk/reward ratio analysis.
    """
    st.subheader("⚖️ Risk/Reward Ratios")
    st.markdown("""
    Analyze your actual risk/reward ratios compared to your planned ratios:
    - Average R:R per trade
    - R:R distribution across symbols
    - Correlation between R:R and win rate
    """)
    
    if trade_analytics.trades_df.empty:
        st.info("No trading data available for Risk/Reward analysis.")
        return

    rr_stats = trade_analytics.calculate_risk_reward_stats()
    st.write(f"Average R:R: {rr_stats['avg_rr']:.2f}")
    st.write(f"Median R:R: {rr_stats['median_rr']:.2f}")
    st.write(f"Winning Trades Avg R:R: {rr_stats['winning_rr']:.2f}")
    st.write(f"Losing Trades Avg R:R: {rr_stats['losing_rr']:.2f}")
    st.write("R:R Distribution:", rr_stats["rr_distribution"])

def render_hold_time_analysis(trade_analytics: TradeAnalytics):
    """
    Render hold time analysis.
    """
    st.subheader("⏱️ Hold Time Analysis")
    st.markdown("""
    Understand your holding patterns:
    - Average hold time for winners vs. losers
    - Optimal hold time by symbol
    - Correlation between hold time and profitability
    """)
    
    if trade_analytics.trades_df.empty:
        st.info("No trading data available for Hold Time analysis.")
        return

    hold_time_stats = trade_analytics.calculate_hold_time_stats()
    st.write(f"Average Hold Time: {hold_time_stats['avg_hold_time']:.2f} minutes")
    st.write(f"Median Hold Time: {hold_time_stats['median_hold_time']:.2f} minutes")
    st.write(f"Winners Avg Hold Time: {hold_time_stats['winners_hold_time']:.2f} minutes")
    st.write(f"Losers Avg Hold Time: {hold_time_stats['losers_hold_time']:.2f} minutes")
    st.write(f"Hold Time-P&L Correlation: {hold_time_stats['hold_time_correlation']:.2f}")

def render_streak_analysis(trade_analytics: TradeAnalytics):
    """
    Render win/loss streak analysis.
    """
    st.subheader("🔥 Win/Loss Streaks")
    st.markdown("""
    Identify patterns in consecutive wins and losses:
    - Longest winning and losing streaks
    - Average streak length
    - Performance degradation during losing streaks
    """)
    
    if trade_analytics.trades_df.empty:
        st.info("No trading data available for Streak analysis.")
        return

    streak_stats = trade_analytics.calculate_streaks()
    st.write(f"Longest Win Streak: {streak_stats['longest_win_streak']}")
    st.write(f"Longest Loss Streak: {streak_stats['longest_loss_streak']}")
    st.write(f"Current Streak: {streak_stats['current_streak']}")
    st.write(f"Average Win Streak: {streak_stats['avg_win_streak']:.2f}")
    st.write(f"Average Loss Streak: {streak_stats['avg_loss_streak']:.2f}")

def render_expectancy_analysis(trade_analytics: TradeAnalytics):
    """
    Render expectancy and profit factor analysis.
    """
    st.subheader("💰 Expectancy & Profit Factor")
    st.markdown("""
    Key profitability metrics:
    - **Expectancy**: Average amount you can expect to win/lose per trade
    - **Profit Factor**: Ratio of gross profit to gross loss
    - Breakdown by symbol and time period
    """)
    
    if trade_analytics.trades_df.empty:
        st.info("No trading data available for Expectancy & Profit Factor analysis.")
        return

    summary = trade_analytics.get_performance_summary()
    st.write(f"Expectancy: ${summary['expectancy']:.2f}")
    st.write(f"Profit Factor: {summary['profit_factor']:.2f}")

def render_prop_compliance_analysis(trade_analytics: TradeAnalytics):
    """
    Render prop firm compliance analysis.
    """
    st.subheader("🏢 Prop Firm Compliance")
    st.markdown("""
    Monitor adherence to prop firm rules:
    - Drawdown limits and current status
    - Daily loss limits
    - Position size violations
    - Trading time restrictions
    - Evaluation simulator for prop challenges
    """)
    
    if trade_analytics.trades_df.empty:
        st.info("No trading data available for Prop Firm Compliance analysis.")
        return

    compliance_stats = trade_analytics.calculate_prop_compliance()
    if compliance_stats["compliant"]:
        st.success("✅ Currently compliant with prop firm rules.")
    else:
        st.error(f"❌ {compliance_stats['violation_count']} prop firm violation(s) detected.")
        for violation in compliance_stats["violations"]:
            st.write(f"- Type: {violation['type'].replace('_', ' ').title()}, Limit: ${violation['limit']:.2f}, Actual: ${violation.get('loss', violation.get('drawdown', violation.get('position_size'))):.2f}")
    st.write(f"Current Max Drawdown: ${compliance_stats['current_drawdown']:.2f} ({compliance_stats['drawdown_percentage']:.2f}% of limit)")

def render_pattern_detection(trade_analytics: TradeAnalytics, journals: List[Dict[str, Any]]):
    """
    Render pattern detection analysis.
    """
    st.subheader("🔍 Pattern Detection")
    st.markdown("""
    AI-powered detection of patterns in your trading:
    - Emotional patterns (FOMO, revenge trading)
    - Market condition patterns (high volatility, low liquidity)
    - Time-of-day patterns
    - Symbol-specific patterns
    - Correlation between journal entries and trade outcomes
    """)
    
    if trade_analytics.trades_df.empty:
        st.info("No trading data available for Pattern Detection.")
        return

    patterns = trade_analytics.detect_patterns(journals)
    if patterns and patterns["pattern_count"] > 0:
        st.write(f"Detected {patterns['pattern_count']} patterns:")
        for pattern in patterns["patterns"]:
            st.markdown(f"**{pattern['description']}**")
            st.write(f"  - Avg P&L: ${pattern['avg_pnl']:.2f}")
            st.write(f"  - Trade Count: {pattern['trade_count']}")
            st.write(f"  - Recommendation: {pattern['recommendation']}")
    else:
        st.info("No significant patterns detected yet. More data may be needed.")

