
"""
AI Insights UI component - Prescriptive and predictive analysis with conversational AI.
This is the core feature with extra emphasis on advanced pattern detection and recommendations.
"""

import streamlit as st
import pandas as pd
from typing import List, Dict, Any, Optional
from datetime import datetime # Import datetime for st.time_input

from src.analysis.nlp_processor import NLPProcessor
from src.analysis.predictive_engine_enhanced import EnhancedPredictiveEngine

def render_page(
    predictive_engine: EnhancedPredictiveEngine,
    nlp_processor: Optional[NLPProcessor],
    trades: List[Dict[str, Any]],
    journals: List[Dict[str, Any]],
    market_data: Dict[str, pd.DataFrame]
):
    """
    Render the AI Insights page with prescriptive and predictive analysis.
    This section has enhanced focus on real-time data, novel patterns, and cross-referencing.
    """
    
    st.header("🤖 AI Insights & Predictions")
    st.markdown("""
    **Advanced AI-powered prescriptive and predictive analysis** that cross-references:
    - Real-time market data and patterns
    - Your complete trading history
    - Journal entries and emotional states
    - Novel patterns not yet discovered
    """)
    
    # Tabs for different insight types
    tab1, tab2, tab3, tab4 = st.tabs([
        "🎯 Prescriptive Analysis",
        "🔮 Predictive Models",
        "🧠 Pattern Discovery",
        "🔗 Cross-Reference Analysis"
    ])
    
    with tab1:
        render_prescriptive_analysis(predictive_engine)
    
    with tab2:
        render_predictive_models(predictive_engine)
    
    with tab3:
        render_pattern_discovery(predictive_engine)
    
    with tab4:
        render_cross_reference_analysis(predictive_engine)

def render_prescriptive_analysis(predictive_engine: EnhancedPredictiveEngine):
    """
    Prescriptive analysis providing real-time actionable recommendations.
    """
    
    st.subheader("🎯 Prescriptive Analysis - Real-Time Recommendations")
    st.markdown("""
    **Prescriptive analysis** provides actionable recommendations based on:
    - Your current trading patterns
    - Real-time market conditions
    - Historical performance data
    - Emotional and psychological states from journals
    """)
    
    # Current recommendations
    st.subheader("📋 Current Recommendations")
    
    if predictive_engine.trades_df.empty:
        st.info("No trading data available for prescriptive analysis. Load sample data or connect your data sources.")
        return

    recommendations = predictive_engine.generate_prescriptive_recommendations()
    
    if recommendations:
        for rec in recommendations:
            priority_color = {"high": "🔴", "medium": "🟡", "low": "🟢"}
            with st.expander(f"{priority_color.get(rec["priority"].lower(), "(Unknown)")} {rec["category"]}: {rec["title"]}"):
                st.markdown(f"**Priority:** {rec['priority'].title()}")
                st.markdown(f"**Category:** {rec['category']}")
                st.markdown(f"**Recommendation:**\n\n{rec['message']}")
                st.markdown(f"**Data Source:** {rec['data_source']}")
                if "actionable_steps" in rec:
                    st.markdown("**Actionable Steps:**")
                    for step in rec["actionable_steps"]:
                        st.markdown(f"- {step}")
                if "expected_impact" in rec:
                    st.markdown(f"**Expected Impact:** {rec["expected_impact"]}")
    else:
        st.info("No significant prescriptive recommendations generated at this time. More data or diverse trading patterns may be needed.")
    
    st.divider()
    st.subheader("⚡ Real-Time Alerts")
    st.markdown("Set up alerts to receive prescriptive recommendations via OneSignal push notifications or email.")
    st.info("Alerts integration is a future enhancement.")

def render_predictive_models(predictive_engine: EnhancedPredictiveEngine):
    """
    Predictive models for forecasting trade outcomes and market edges.
    """
    
    st.subheader("🔮 Predictive Models - Forecast Your Edge")
    st.markdown("""
    **Predictive models** use machine learning to forecast:
    - Probability of success for potential trades
    - Expected P&L based on current conditions
    - Optimal entry/exit points
    - Market regime changes
    """)
    
    if predictive_engine.trades_df.empty:
        st.info("No trading data available for predictive models. Load sample data or connect your data sources.")
        return

    st.subheader("📊 Trade Outcome Predictor")
    st.markdown("""
    Predict the probability of success for a potential trade based on:
    - Current market conditions (volatility, trend, session)
    - Your historical performance in similar conditions
    - Your current emotional state (from recent journals)
    - Time of day and day of week patterns
    """)
    
    # Input form for prediction
    col1, col2 = st.columns(2)
    with col1:
        pred_symbol = st.selectbox("Symbol", predictive_engine.trades_df["symbol"].unique() if not predictive_engine.trades_df.empty else ["MES"])
        pred_direction = st.selectbox("Direction", ["long", "short"])
        pred_volatility = st.slider("Current Volatility (e.g., ATR)", 0.1, 5.0, 1.5)
    
    with col2:
        pred_time = st.time_input("Entry Time", value=datetime.now().time())
        pred_emotional_state = st.selectbox("Current Emotional State", predictive_engine.journals_df["emotional_state"].dropna().unique() if not predictive_engine.journals_df.empty else ["calm", "neutral", "confident"])
        
    if st.button("🎯 Predict Outcome"):
        with st.spinner("Generating prediction..."):
            prediction = predictive_engine.predict_trade_outcome(
                symbol=pred_symbol,
                direction=pred_direction,
                current_volatility=pred_volatility,
                emotional_state=pred_emotional_state,
                time_of_day=pred_time.hour
            )
            
            st.subheader("Prediction Result:")
            st.write(f"**Probability of Success:** {prediction['probability']:.2f}")
            st.write(f"**Confidence:** {prediction['confidence'].title()}")
            st.write(f"**Recommendation:** {prediction['recommendation']}")
            
            if prediction["factors"]:
                st.markdown("**Contributing Factors:**")
                for factor in prediction["factors"]:
                    st.write(f"- {factor['factor']}: {factor['description']}")
            
            # XAI Explanation
            st.markdown("--- ")
            st.subheader("Explainable AI (XAI) Insights:")
            explanation = predictive_engine.explain_prediction(prediction)
            
            st.write("**Prediction Summary:**")
            st.json(explanation["prediction_summary"])
            
            st.write("**Factor Breakdown:**")
            st.dataframe(pd.DataFrame(explanation["factor_breakdown"])) # Display as DataFrame
            
            st.write("**Decision Path:**")
            st.dataframe(pd.DataFrame(explanation["decision_path"])) # Display as DataFrame
            
            st.write("**Counterfactual Scenarios:**")
            st.dataframe(pd.DataFrame(explanation["counterfactuals"])) # Display as DataFrame

def render_pattern_discovery(predictive_engine: EnhancedPredictiveEngine):
    """
    Novel pattern discovery using unsupervised learning and cross-referencing.
    """
    
    st.subheader("🧠 Pattern Discovery - Find Hidden Insights")
    st.markdown("""
    **Discover novel patterns** that you haven\\\\\\\\'t thought of yet by cross-referencing:
    - Trading history patterns
    - Journal entry patterns
    - Market data patterns
    - Temporal patterns (time of day, day of week, market sessions)
    - Emotional and psychological patterns
    """)
    
    if predictive_engine.trades_df.empty:
        st.info("No trading data available for pattern discovery. Load sample data or connect your data sources.")
        return

    if st.button("🔍 Discover Novel Patterns"):
        with st.spinner("Analyzing patterns across all data sources..."):
            patterns = predictive_engine.discover_novel_patterns()
            
            if patterns:
                st.subheader("📋 Discovered Patterns")
                for pattern in patterns:
                    with st.expander(f"**{pattern['pattern_type']}:** {pattern['description']}"):
                        st.write(f"**Type:** {pattern['type'].replace("_", " ").title()}")
                        st.write(f"**Average P&L:** ${pattern['avg_pnl']:.2f}")
                        st.write(f"**Trade Count:** {pattern['trade_count']}")
                        st.write(f"**Recommendation:** {pattern['recommendation']}")
                        if "characteristics" in pattern:
                            st.write("**Characteristics:**")
                            if isinstance(pattern["characteristics"], dict):
                                for k, v in pattern["characteristics"].items():
                                    st.write(f"- {k.replace("_", " ").title()}: {v}")
                            else:
                                for char in pattern["characteristics"]:
                                    st.write(f"- {char}")
            else:
                st.info("No significant novel patterns detected. More data or diverse trading patterns may be needed.")

def render_cross_reference_analysis(predictive_engine: EnhancedPredictiveEngine):
    """
    Cross-reference analysis to find correlations and causal relationships.
    """
    st.subheader("🔗 Cross-Reference Analysis")
    st.markdown("""
    **Cross-Reference Analysis** finds correlations and potential causal relationships between different data sources:
    - Journal sentiment vs. Trade outcomes
    - Market volatility vs. Your performance
    - Emotional states vs. Rule adherence
    - Time patterns vs. Win rate
    """)

    if predictive_engine.merged_data.empty:
        st.info("No merged data available for cross-reference analysis. Load sample data or connect your data sources.")
        return

    if st.button("🔬 Run Cross-Reference Analysis"):
        with st.spinner("Performing advanced cross-reference analysis..."):
            analysis_results = predictive_engine.advanced_cross_reference()

            st.subheader("Correlations:")
            if analysis_results["correlations"]:
                st.dataframe(pd.DataFrame(analysis_results["correlations"])) # Display as DataFrame
            else:
                st.info("No significant correlations found.")

            st.subheader("Insights:")
            if analysis_results["insights"]:
                for insight in analysis_results["insights"]:
                    st.write(f"- **{insight['type'].replace("_", " ").title()}:** {insight['description']} (Confidence: {insight['confidence'].title()})")
            else:
                st.info("No significant insights found.")

            st.subheader("Causal Relationships:")
            if analysis_results["causal_relationships"]:
                for causal in analysis_results["causal_relationships"]:
                    st.write(f"- **Cause:** {causal['cause']}\n  **Effect:** {causal['effect']}\n  **Description:** {causal['description']}\n  **Recommendation:** {causal['recommendation']}")
            else:
                st.info("No significant causal relationships found.")


