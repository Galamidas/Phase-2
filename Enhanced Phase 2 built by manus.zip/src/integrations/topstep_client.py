"""
TopStep API client module for retrieving trade data.
Handles authentication and data fetching from TopStep trading platform.
"""

import requests
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from config.config import Config
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TopStepClient:
    """
    Client for interacting with TopStep API to fetch trade data.
    """
    
    def __init__(self, api_key: Optional[str] = None, api_url: Optional[str] = None):
        """
        Initialize TopStep API client.
        
        Args:
            api_key: TopStep API key (defaults to Config.TOPSTEP_API_KEY)
            api_url: TopStep API base URL (defaults to Config.TOPSTEP_API_URL)
        """
        self.api_key = api_key or Config.TOPSTEP_API_KEY
        self.api_url = api_url or Config.TOPSTEP_API_URL
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        })
    
    def test_connection(self) -> bool:
        """
        Test the TopStep API connection.
        
        Returns:
            True if connection is successful, False otherwise
        """
        try:
            # Attempt to fetch account info as a connection test
            response = self.session.get(f"{self.api_url}/account")
            response.raise_for_status()
            logger.info("TopStep API connection test successful")
            return True
        except requests.exceptions.RequestException as e:
            logger.error(f"TopStep API connection test failed: {e}")
            return False
    
    def get_trades(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        symbol: Optional[str] = None,
        status: str = "all"
    ) -> List[Dict[str, Any]]:
        """
        Fetch trades from TopStep API.
        
        Args:
            start_date: Start date for trade history (defaults to 90 days ago)
            end_date: End date for trade history (defaults to now)
            symbol: Filter by specific symbol (MGC, MES, M2K)
            status: Filter by trade status (all, open, closed)
        
        Returns:
            List of trade dictionaries
        """
        if not start_date:
            start_date = datetime.now() - timedelta(days=90)
        if not end_date:
            end_date = datetime.now()
        
        try:
            params = {
                "start_date": start_date.isoformat(),
                "end_date": end_date.isoformat(),
                "status": status
            }
            
            if symbol:
                params["symbol"] = symbol
            
            response = self.session.get(f"{self.api_url}/trades", params=params)
            response.raise_for_status()
            
            trades = response.json().get("trades", [])
            logger.info(f"Fetched {len(trades)} trades from TopStep API")
            
            # Transform trades to our internal format
            return [self._transform_trade(trade) for trade in trades]
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching trades from TopStep API: {e}")
            return []
    
    def get_account_info(self) -> Optional[Dict[str, Any]]:
        """
        Fetch account information from TopStep API.
        
        Returns:
            Account information dictionary or None if failed
        """
        try:
            response = self.session.get(f"{self.api_url}/account")
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching account info: {e}")
            return None
    
    def get_account_metrics(self) -> Optional[Dict[str, Any]]:
        """
        Fetch account performance metrics from TopStep API.
        
        Returns:
            Metrics dictionary including win rate, profit factor, etc.
        """
        try:
            response = self.session.get(f"{self.api_url}/account/metrics")
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching account metrics: {e}")
            return None
    
    def get_evaluation_status(self) -> Optional[Dict[str, Any]]:
        """
        Fetch prop firm evaluation status (for prop challenges).
        
        Returns:
            Evaluation status including drawdown limits, daily loss limits, etc.
        """
        try:
            response = self.session.get(f"{self.api_url}/evaluation/status")
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching evaluation status: {e}")
            return None
    
    def _transform_trade(self, trade: Dict[str, Any]) -> Dict[str, Any]:
        """
        Transform TopStep trade format to our internal format.
        
        Args:
            trade: Trade data from TopStep API
        
        Returns:
            Transformed trade dictionary
        """
        # Calculate derived metrics
        entry_time = datetime.fromisoformat(trade.get("entry_time", ""))
        exit_time = datetime.fromisoformat(trade.get("exit_time", "")) if trade.get("exit_time") else None
        
        hold_time_minutes = None
        if exit_time:
            hold_time_minutes = int((exit_time - entry_time).total_seconds() / 60)
        
        entry_price = float(trade.get("entry_price", 0))
        exit_price = float(trade.get("exit_price", 0)) if trade.get("exit_price") else None
        position_size = float(trade.get("position_size", 0))
        
        pnl = None
        pnl_percent = None
        if exit_price:
            if trade.get("direction") == "long":
                pnl = (exit_price - entry_price) * position_size
            else:  # short
                pnl = (entry_price - exit_price) * position_size
            
            if entry_price > 0:
                pnl_percent = (pnl / (entry_price * position_size)) * 100
        
        # Calculate risk/reward ratio if stop loss and take profit are available
        risk_reward_ratio = None
        stop_loss = trade.get("stop_loss")
        take_profit = trade.get("take_profit")
        
        if stop_loss and take_profit:
            risk = abs(entry_price - float(stop_loss))
            reward = abs(float(take_profit) - entry_price)
            if risk > 0:
                risk_reward_ratio = reward / risk
        
        return {
            "external_trade_id": trade.get("id"),
            "symbol": trade.get("symbol"),
            "direction": trade.get("direction"),
            "entry_time": entry_time,
            "exit_time": exit_time,
            "entry_price": entry_price,
            "exit_price": exit_price,
            "position_size": position_size,
            "pnl": pnl,
            "pnl_percent": pnl_percent,
            "commission": float(trade.get("commission", 0)),
            "slippage": float(trade.get("slippage", 0)),
            "mfe": float(trade.get("mfe", 0)) if trade.get("mfe") else None,
            "mae": float(trade.get("mae", 0)) if trade.get("mae") else None,
            "hold_time_minutes": hold_time_minutes,
            "risk_amount": float(trade.get("risk_amount", 0)) if trade.get("risk_amount") else None,
            "reward_amount": float(trade.get("reward_amount", 0)) if trade.get("reward_amount") else None,
            "risk_reward_ratio": risk_reward_ratio,
            "stop_loss": float(stop_loss) if stop_loss else None,
            "take_profit": float(take_profit) if take_profit else None,
            "status": trade.get("status", "closed"),
            "notes": trade.get("notes", "")
        }
    
    def sync_trades_to_database(self, supabase_client, user_id: str, days_back: int = 90) -> int:
        """
        Sync trades from TopStep API to Supabase database.
        
        Args:
            supabase_client: SupabaseClient instance
            user_id: User ID for the trades
            days_back: Number of days to look back for trades
        
        Returns:
            Number of trades synced
        """
        try:
            # Fetch trades from TopStep
            start_date = datetime.now() - timedelta(days=days_back)
            trades = self.get_trades(start_date=start_date)
            
            if not trades:
                logger.info("No trades to sync")
                return 0
            
            # Add user_id to each trade
            for trade in trades:
                trade["user_id"] = user_id
            
            # Bulk insert to database
            success = supabase_client.bulk_insert_trades(trades)
            
            if success:
                logger.info(f"Successfully synced {len(trades)} trades to database")
                return len(trades)
            else:
                logger.error("Failed to sync trades to database")
                return 0
        
        except Exception as e:
            logger.error(f"Error syncing trades: {e}")
            return 0

# Global instance
_topstep_client = None

def get_topstep_client(api_key: Optional[str] = None) -> TopStepClient:
    """
    Get or create the global TopStep client instance.
    
    Args:
        api_key: Optional API key to override config
    
    Returns:
        TopStepClient instance
    """
    global _topstep_client
    if _topstep_client is None or api_key:
        _topstep_client = TopStepClient(api_key=api_key)
    return _topstep_client
