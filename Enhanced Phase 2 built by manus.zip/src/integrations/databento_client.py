"""
Databento API client module for retrieving real-time and historical market data.
Handles OHLCV data fetching for futures contracts (MGC, MES, M2K).
"""

import databento as db
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from config.config import Config
import pandas as pd
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabentoClient:
    """
    Client for interacting with Databento API to fetch market data.
    """
    
    # Symbol mappings for Databento
    SYMBOL_MAPPING = {
        "MGC": "MGC.FUT",  # Micro Gold Futures
        "MES": "MES.FUT",  # Micro E-mini S&P 500 Futures
        "M2K": "M2K.FUT"   # Micro E-mini Russell 2000 Futures
    }
    
    # Timeframe mappings
    TIMEFRAME_MAPPING = {
        "1m": "1m",
        "5m": "5m",
        "15m": "15m",
        "30m": "30m",
        "1h": "1h",
        "4h": "4h",
        "1d": "1d"
    }
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize Databento API client.
        
        Args:
            api_key: Databento API key (defaults to Config.DATABENTO_API_KEY)
        """
        self.api_key = api_key or Config.DATABENTO_API_KEY
        
        if not self.api_key:
            logger.warning("Databento API key not configured")
            self.client = None
        else:
            try:
                self.client = db.Historical(self.api_key)
                logger.info("Databento client initialized successfully")
            except Exception as e:
                logger.error(f"Failed to initialize Databento client: {e}")
                self.client = None
    
    def test_connection(self) -> bool:
        """
        Test the Databento API connection.
        
        Returns:
            True if connection is successful, False otherwise
        """
        if not self.client:
            logger.error("Databento client not initialized")
            return False
        
        try:
            # Try to fetch a small amount of data as a connection test
            _ = self.client.timeseries.get_range(
                dataset="GLBX.MDP3",
                symbols=["MES.FUT"],
                schema="ohlcv-1h",
                start="2024-01-01",
                end="2024-01-02"
            )
            logger.info("Databento API connection test successful")
            return True
        except Exception as e:
            logger.error(f"Databento API connection test failed: {e}")
            return False
    
    def get_ohlcv(
        self,
        symbol: str,
        timeframe: str = "1h",
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        limit: int = 1000
    ) -> pd.DataFrame:
        """
        Fetch OHLCV (candlestick) data for a symbol.
        
        Args:
            symbol: Trading symbol (MGC, MES, M2K)
            timeframe: Candle timeframe (1m, 5m, 15m, 30m, 1h, 4h, 1d)
            start_date: Start date for data (defaults to 30 days ago)
            end_date: End date for data (defaults to now)
            limit: Maximum number of candles to return
        
        Returns:
            DataFrame with columns: timestamp, open, high, low, close, volume
        """
        if not self.client:
            logger.error("Databento client not initialized")
            return pd.DataFrame()
        
        if not start_date:
            start_date = datetime.now() - timedelta(days=30)
        if not end_date:
            end_date = datetime.now()
        
        try:
            # Map symbol to Databento format
            databento_symbol = self.SYMBOL_MAPPING.get(symbol, symbol)
            
            # Map timeframe to Databento schema
            schema = f"ohlcv-{timeframe}"
            
            # Fetch data from Databento
            data = self.client.timeseries.get_range(
                dataset="GLBX.MDP3",  # CME Globex dataset
                symbols=[databento_symbol],
                schema=schema,
                start=start_date.strftime("%Y-%m-%d"),
                end=end_date.strftime("%Y-%m-%d")
            )
            
            # Convert to DataFrame
            df = data.to_df()
            
            if df.empty:
                logger.warning(f"No data returned for {symbol} {timeframe}")
                return pd.DataFrame()
            
            # Standardize column names
            df = df.rename(columns={
                "ts_event": "timestamp",
                "open": "open",
                "high": "high",
                "low": "low",
                "close": "close",
                "volume": "volume"
            })
            
            # Ensure timestamp is datetime
            if "timestamp" in df.columns:
                df["timestamp"] = pd.to_datetime(df["timestamp"])
            
            # Limit number of rows
            if len(df) > limit:
                df = df.tail(limit)
            
            logger.info(f"Fetched {len(df)} candles for {symbol} {timeframe}")
            return df
        
        except Exception as e:
            logger.error(f"Error fetching OHLCV data: {e}")
            return pd.DataFrame()
    
    def get_real_time_quote(self, symbol: str) -> Optional[Dict[str, Any]]:
        """
        Fetch real-time quote for a symbol.
        
        Args:
            symbol: Trading symbol (MGC, MES, M2K)
        
        Returns:
            Dictionary with current price, bid, ask, volume
        """
        if not self.client:
            logger.error("Databento client not initialized")
            return None
        
        try:
            # Map symbol to Databento format
            databento_symbol = self.SYMBOL_MAPPING.get(symbol, symbol)
            
            # Fetch latest quote
            data = self.client.timeseries.get_range(
                dataset="GLBX.MDP3",
                symbols=[databento_symbol],
                schema="mbp-1",  # Market by price (level 1)
                start=datetime.now() - timedelta(minutes=5),
                end=datetime.now()
            )
            
            df = data.to_df()
            
            if df.empty:
                logger.warning(f"No real-time data for {symbol}")
                return None
            
            # Get the latest quote
            latest = df.iloc[-1]
            
            return {
                "symbol": symbol,
                "timestamp": latest.get("ts_event"),
                "bid": latest.get("bid_px_00"),
                "ask": latest.get("ask_px_00"),
                "last": latest.get("price"),
                "volume": latest.get("size")
            }
        
        except Exception as e:
            logger.error(f"Error fetching real-time quote: {e}")
            return None
    
    def calculate_atr(self, df: pd.DataFrame, period: int = 14) -> pd.Series:
        """
        Calculate Average True Range (ATR) for volatility measurement.
        
        Args:
            df: DataFrame with OHLC data
            period: ATR period (default 14)
        
        Returns:
            Series with ATR values
        """
        if df.empty or len(df) < period:
            return pd.Series()
        
        try:
            # Calculate True Range
            high_low = df["high"] - df["low"]
            high_close = abs(df["high"] - df["close"].shift())
            low_close = abs(df["low"] - df["close"].shift())
            
            true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
            
            # Calculate ATR as moving average of True Range
            atr = true_range.rolling(window=period).mean()
            
            return atr
        
        except Exception as e:
            logger.error(f"Error calculating ATR: {e}")
            return pd.Series()
    
    def sync_market_data_to_database(
        self,
        supabase_client,
        symbol: str,
        timeframe: str = "1h",
        days_back: int = 30
    ) -> int:
        """
        Sync market data from Databento to Supabase database.
        
        Args:
            supabase_client: SupabaseClient instance
            symbol: Trading symbol (MGC, MES, M2K)
            timeframe: Candle timeframe
            days_back: Number of days to look back
        
        Returns:
            Number of candles synced
        """
        try:
            # Fetch OHLCV data
            start_date = datetime.now() - timedelta(days=days_back)
            df = self.get_ohlcv(symbol, timeframe, start_date)
            
            if df.empty:
                logger.info(f"No market data to sync for {symbol}")
                return 0
            
            # Calculate ATR
            df["atr"] = self.calculate_atr(df)
            
            # Convert DataFrame to list of dictionaries
            market_data = []
            for _, row in df.iterrows():
                market_data.append({
                    "symbol": symbol,
                    "timeframe": timeframe,
                    "timestamp": row["timestamp"],
                    "open": float(row["open"]),
                    "high": float(row["high"]),
                    "low": float(row["low"]),
                    "close": float(row["close"]),
                    "volume": int(row["volume"]) if pd.notna(row["volume"]) else None,
                    "atr": float(row["atr"]) if pd.notna(row["atr"]) else None
                })
            
            # Insert to database
            success = supabase_client.insert_market_data(market_data)
            
            if success:
                logger.info(f"Successfully synced {len(market_data)} candles for {symbol} {timeframe}")
                return len(market_data)
            else:
                logger.error("Failed to sync market data to database")
                return 0
        
        except Exception as e:
            logger.error(f"Error syncing market data: {e}")
            return 0
    
    def get_market_context(self, symbol: str, timestamp: datetime) -> Dict[str, Any]:
        """
        Get market context (volatility, session, etc.) for a specific timestamp.
        Useful for correlating with journal entries and trades.
        
        Args:
            symbol: Trading symbol
            timestamp: Timestamp to get context for
        
        Returns:
            Dictionary with market context information
        """
        try:
            # Fetch data around the timestamp
            start_date = timestamp - timedelta(hours=24)
            end_date = timestamp + timedelta(hours=1)
            
            df = self.get_ohlcv(symbol, "1h", start_date, end_date)
            
            if df.empty:
                return {}
            
            # Calculate ATR for volatility
            df["atr"] = self.calculate_atr(df)
            
            # Find the closest candle to the timestamp
            df["time_diff"] = abs(df["timestamp"] - timestamp)
            closest_idx = df["time_diff"].idxmin()
            closest_candle = df.loc[closest_idx]
            
            # Determine trading session
            hour = timestamp.hour
            if 8 <= hour < 16:
                session = "london"
            elif 13 <= hour < 21:
                session = "new_york"
            elif 18 <= hour < 2:
                session = "asian"
            else:
                session = "off_hours"
            
            # Determine volatility level
            atr_value = closest_candle["atr"] if pd.notna(closest_candle["atr"]) else 0
            if atr_value > 2.5:
                volatility = "high"
            elif atr_value > 1.5:
                volatility = "medium"
            else:
                volatility = "low"
            
            return {
                "atr": float(atr_value),
                "session": session,
                "volatility": volatility,
                "price": float(closest_candle["close"]),
                "volume": int(closest_candle["volume"]) if pd.notna(closest_candle["volume"]) else None
            }
        
        except Exception as e:
            logger.error(f"Error getting market context: {e}")
            return {}

# Global instance
_databento_client = None

def get_databento_client(api_key: Optional[str] = None) -> DatabentoClient:
    """
    Get or create the global Databento client instance.
    
    Args:
        api_key: Optional API key to override config
    
    Returns:
        DatabentoClient instance
    """
    global _databento_client
    if _databento_client is None or api_key:
        _databento_client = DatabentoClient(api_key=api_key)
    return _databento_client
