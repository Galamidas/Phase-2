"""
Supabase client module for database operations.
Handles connection to Supabase and provides CRUD operations for all tables.
"""

from supabase import create_client, Client
from config.config import Config
from typing import Optional, List, Dict, Any
from datetime import datetime
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SupabaseClient:
    """
    Wrapper class for Supabase client with helper methods for common operations.
    """
    
    def __init__(self):
        """Initialize Supabase client with credentials from config."""
        try:
            self.client: Client = create_client(
                Config.SUPABASE_URL,
                Config.SUPABASE_KEY
            )
            logger.info("Supabase client initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize Supabase client: {e}")
            raise
    
    # ==================== Journal Operations ====================
    
    def get_journals(
        self,
        user_id: Optional[str] = None,
        symbol: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        tags: Optional[List[str]] = None,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """
        Retrieve journal entries with optional filters.
        
        Args:
            user_id: Filter by user ID
            symbol: Filter by trading symbol (MGC, MES, M2K)
            start_date: Filter entries after this date
            end_date: Filter entries before this date
            tags: Filter by tags
            limit: Maximum number of entries to return
        
        Returns:
            List of journal entry dictionaries
        """
        try:
            query = self.client.table(Config.TABLE_JOURNALS).select("*")
            
            if user_id:
                query = query.eq("user_id", user_id)
            if symbol:
                query = query.eq("symbol", symbol)
            if start_date:
                query = query.gte("timestamp", start_date.isoformat())
            if end_date:
                query = query.lte("timestamp", end_date.isoformat())
            if tags:
                query = query.contains("tags", tags)
            
            query = query.order("timestamp", desc=True).limit(limit)
            
            response = query.execute()
            return response.data
        except Exception as e:
            logger.error(f"Error fetching journals: {e}")
            return []
    
    def insert_journal(self, journal_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Insert a new journal entry.
        
        Args:
            journal_data: Dictionary containing journal entry data
        
        Returns:
            Inserted journal entry or None if failed
        """
        try:
            response = self.client.table(Config.TABLE_JOURNALS).insert(journal_data).execute()
            logger.info(f"Journal entry inserted: {response.data[0].get('id')}")
            return response.data[0]
        except Exception as e:
            logger.error(f"Error inserting journal: {e}")
            return None
    
    def update_journal(self, journal_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Update an existing journal entry.
        
        Args:
            journal_id: ID of the journal entry to update
            updates: Dictionary of fields to update
        
        Returns:
            Updated journal entry or None if failed
        """
        try:
            response = self.client.table(Config.TABLE_JOURNALS).update(updates).eq("id", journal_id).execute()
            logger.info(f"Journal entry updated: {journal_id}")
            return response.data[0] if response.data else None
        except Exception as e:
            logger.error(f"Error updating journal: {e}")
            return None
    
    # ==================== Trade Operations ====================
    
    def get_trades(
        self,
        user_id: Optional[str] = None,
        symbol: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        profitable_only: bool = False,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """
        Retrieve trades with optional filters.
        
        Args:
            user_id: Filter by user ID
            symbol: Filter by trading symbol
            start_date: Filter trades after this date
            end_date: Filter trades before this date
            profitable_only: Only return profitable trades
            limit: Maximum number of trades to return
        
        Returns:
            List of trade dictionaries
        """
        try:
            query = self.client.table(Config.TABLE_TRADES).select("*")
            
            if user_id:
                query = query.eq("user_id", user_id)
            if symbol:
                query = query.eq("symbol", symbol)
            if start_date:
                query = query.gte("entry_time", start_date.isoformat())
            if end_date:
                query = query.lte("exit_time", end_date.isoformat())
            if profitable_only:
                query = query.gt("pnl", 0)
            
            query = query.order("entry_time", desc=True).limit(limit)
            
            response = query.execute()
            return response.data
        except Exception as e:
            logger.error(f"Error fetching trades: {e}")
            return []
    
    def insert_trade(self, trade_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Insert a new trade.
        
        Args:
            trade_data: Dictionary containing trade data
        
        Returns:
            Inserted trade or None if failed
        """
        try:
            response = self.client.table(Config.TABLE_TRADES).insert(trade_data).execute()
            logger.info(f"Trade inserted: {response.data[0].get('id')}")
            return response.data[0]
        except Exception as e:
            logger.error(f"Error inserting trade: {e}")
            return None
    
    def bulk_insert_trades(self, trades: List[Dict[str, Any]]) -> bool:
        """
        Insert multiple trades at once.
        
        Args:
            trades: List of trade dictionaries
        
        Returns:
            True if successful, False otherwise
        """
        try:
            response = self.client.table(Config.TABLE_TRADES).insert(trades).execute()
            logger.info(f"Bulk inserted {len(response.data)} trades")
            return True
        except Exception as e:
            logger.error(f"Error bulk inserting trades: {e}")
            return False
    
    # ==================== Market Data Operations ====================
    
    def get_market_data(
        self,
        symbol: str,
        start_time: datetime,
        end_time: datetime,
        timeframe: str = "1h"
    ) -> List[Dict[str, Any]]:
        """
        Retrieve market data (OHLCV) for a symbol and time range.
        
        Args:
            symbol: Trading symbol
            start_time: Start of time range
            end_time: End of time range
            timeframe: Candle timeframe (1m, 5m, 15m, 1h, 4h, 1d)
        
        Returns:
            List of OHLCV data dictionaries
        """
        try:
            query = self.client.table(Config.TABLE_MARKET_DATA).select("*")
            query = query.eq("symbol", symbol)
            query = query.eq("timeframe", timeframe)
            query = query.gte("timestamp", start_time.isoformat())
            query = query.lte("timestamp", end_time.isoformat())
            query = query.order("timestamp", desc=False)
            
            response = query.execute()
            return response.data
        except Exception as e:
            logger.error(f"Error fetching market data: {e}")
            return []
    
    def insert_market_data(self, market_data: List[Dict[str, Any]]) -> bool:
        """
        Insert market data (OHLCV) in bulk.
        
        Args:
            market_data: List of OHLCV data dictionaries
        
        Returns:
            True if successful, False otherwise
        """
        try:
            response = self.client.table(Config.TABLE_MARKET_DATA).insert(market_data).execute()
            logger.info(f"Inserted {len(response.data)} market data records")
            return True
        except Exception as e:
            logger.error(f"Error inserting market data: {e}")
            return False
    
    # ==================== Tag Operations ====================
    
    def get_all_tags(self, user_id: Optional[str] = None) -> List[str]:
        """
        Get all unique tags used in journals.
        
        Args:
            user_id: Filter by user ID
        
        Returns:
            List of unique tag strings
        """
        try:
            query = self.client.table(Config.TABLE_TAGS).select("tag")
            if user_id:
                query = query.eq("user_id", user_id)
            
            response = query.execute()
            return [item["tag"] for item in response.data]
        except Exception as e:
            logger.error(f"Error fetching tags: {e}")
            return []
    
    def insert_tag(self, tag: str, user_id: Optional[str] = None) -> bool:
        """
        Insert a new tag.
        
        Args:
            tag: Tag string
            user_id: User ID who created the tag
        
        Returns:
            True if successful, False otherwise
        """
        try:
            tag_data = {"tag": tag, "user_id": user_id, "created_at": datetime.utcnow().isoformat()}
            response = self.client.table(Config.TABLE_TAGS).insert(tag_data).execute()
            return True
        except Exception as e:
            logger.error(f"Error inserting tag: {e}")
            return False
    
    # ==================== User Operations ====================
    
    def get_user(self, user_id: str) -> Optional[Dict[str, Any]]:
        """
        Get user information.
        
        Args:
            user_id: User ID
        
        Returns:
            User data dictionary or None
        """
        try:
            response = self.client.table(Config.TABLE_USERS).select("*").eq("id", user_id).execute()
            return response.data[0] if response.data else None
        except Exception as e:
            logger.error(f"Error fetching user: {e}")
            return None
    
    def create_user(self, user_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Create a new user.
        
        Args:
            user_data: User data dictionary
        
        Returns:
            Created user data or None
        """
        try:
            response = self.client.table(Config.TABLE_USERS).insert(user_data).execute()
            logger.info(f"User created: {response.data[0].get('id')}")
            return response.data[0]
        except Exception as e:
            logger.error(f"Error creating user: {e}")
            return None
    
    # ==================== Utility Methods ====================
    
    def test_connection(self) -> bool:
        """
        Test the Supabase connection.
        
        Returns:
            True if connection is successful, False otherwise
        """
        try:
            # Try to fetch one record from users table
            self.client.table(Config.TABLE_USERS).select("id").limit(1).execute()
            logger.info("Supabase connection test successful")
            return True
        except Exception as e:
            logger.error(f"Supabase connection test failed: {e}")
            return False

# Global instance
_supabase_client = None

def get_supabase_client() -> SupabaseClient:
    """
    Get or create the global Supabase client instance.
    
    Returns:
        SupabaseClient instance
    """
    global _supabase_client
    if _supabase_client is None:
        _supabase_client = SupabaseClient()
    return _supabase_client
