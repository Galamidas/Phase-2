"""
Chart builder module for creating interactive Plotly charts.
Includes candlestick charts with trade entries/exits and journal annotations.
"""

import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
from typing import List, Dict, Any, Optional
from datetime import datetime
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ChartBuilder:
    """
    Builder for creating interactive trading charts with overlays.
    """
    
    def __init__(self):
        """Initialize chart builder."""
        self.default_colors = {
            "up": "#26a69a",  # Green for bullish candles
            "down": "#ef5350",  # Red for bearish candles
            "long_entry": "#2196f3",  # Blue for long entries
            "short_entry": "#ff9800",  # Orange for short entries
            "exit": "#9c27b0",  # Purple for exits
            "journal": "#ffc107"  # Yellow for journal annotations
        }
    
    def create_candlestick_chart(
        self,
        market_data: pd.DataFrame,
        trades: Optional[List[Dict[str, Any]]] = None,
        journals: Optional[List[Dict[str, Any]]] = None,
        symbol: str = "MES",
        timeframe: str = "1h",
        show_volume: bool = True,
        show_indicators: bool = False
    ) -> go.Figure:
        """
        Create an interactive candlestick chart with trade and journal overlays.
        
        Args:
            market_data: DataFrame with OHLCV data
            trades: List of trade dictionaries
            journals: List of journal dictionaries
            symbol: Trading symbol
            timeframe: Chart timeframe
            show_volume: Whether to show volume subplot
            show_indicators: Whether to show technical indicators
        
        Returns:
            Plotly Figure object
        """
        if market_data.empty:
            logger.warning("No market data provided for chart")
            return self._create_empty_chart(symbol)
        
        # Create subplots
        rows = 2 if show_volume else 1
        row_heights = [0.7, 0.3] if show_volume else [1.0]
        
        fig = make_subplots(
            rows=rows,
            cols=1,
            shared_xaxes=True,
            vertical_spacing=0.03,
            row_heights=row_heights,
            subplot_titles=(f"{symbol} - {timeframe}", "Volume") if show_volume else (f"{symbol} - {timeframe}",)
        )
        
        # Add candlestick chart
        fig.add_trace(
            go.Candlestick(
                x=market_data['timestamp'],
                open=market_data['open'],
                high=market_data['high'],
                low=market_data['low'],
                close=market_data['close'],
                name=symbol,
                increasing_line_color=self.default_colors['up'],
                decreasing_line_color=self.default_colors['down']
            ),
            row=1, col=1
        )
        
        # Add trade markers
        if trades:
            self._add_trade_markers(fig, trades, market_data)
        
        # Add journal annotations
        if journals:
            self._add_journal_annotations(fig, journals, market_data)
        
        # Add volume bars
        if show_volume and 'volume' in market_data.columns:
            colors = [self.default_colors['up'] if close >= open else self.default_colors['down']
                     for close, open in zip(market_data['close'], market_data['open'])]
            
            fig.add_trace(
                go.Bar(
                    x=market_data['timestamp'],
                    y=market_data['volume'],
                    name='Volume',
                    marker_color=colors,
                    showlegend=False
                ),
                row=2, col=1
            )
        
        # Add technical indicators
        if show_indicators and 'atr' in market_data.columns:
            self._add_atr_indicator(fig, market_data)
        
        # Update layout
        fig.update_layout(
            title=f"{symbol} Price Chart - {timeframe}",
            xaxis_title="Time",
            yaxis_title="Price",
            height=800 if show_volume else 600,
            xaxis_rangeslider_visible=False,
            hovermode='x unified',
            template='plotly_dark',
            showlegend=True,
            legend=dict(
                yanchor="top",
                y=0.99,
                xanchor="left",
                x=0.01
            )
        )
        
        # Update axes
        fig.update_xaxes(
            showgrid=True,
            gridwidth=1,
            gridcolor='rgba(128, 128, 128, 0.2)'
        )
        fig.update_yaxes(
            showgrid=True,
            gridwidth=1,
            gridcolor='rgba(128, 128, 128, 0.2)'
        )
        
        logger.info(f"Created candlestick chart for {symbol}")
        return fig
    
    def _add_trade_markers(
        self,
        fig: go.Figure,
        trades: List[Dict[str, Any]],
        market_data: pd.DataFrame
    ):
        """
        Add trade entry and exit markers to the chart.
        
        Args:
            fig: Plotly figure
            trades: List of trade dictionaries
            market_data: Market data DataFrame
        """
        entry_times_long = []
        entry_prices_long = []
        entry_times_short = []
        entry_prices_short = []
        exit_times = []
        exit_prices = []
        
        for trade in trades:
            # Entry markers
            if trade.get('entry_time') and trade.get('entry_price'):
                if trade.get('direction') == 'long':
                    entry_times_long.append(trade['entry_time'])
                    entry_prices_long.append(trade['entry_price'])
                else:
                    entry_times_short.append(trade['entry_time'])
                    entry_prices_short.append(trade['entry_price'])
            
            # Exit markers
            if trade.get('exit_time') and trade.get('exit_price'):
                exit_times.append(trade['exit_time'])
                exit_prices.append(trade['exit_price'])
                
                # Draw line from entry to exit
                if trade.get('entry_time') and trade.get('entry_price'):
                    color = 'green' if trade.get('pnl', 0) > 0 else 'red'
                    fig.add_trace(
                        go.Scatter(
                            x=[trade['entry_time'], trade['exit_time']],
                            y=[trade['entry_price'], trade['exit_price']],
                            mode='lines',
                            line=dict(color=color, width=1, dash='dot'),
                            showlegend=False,
                            hoverinfo='skip'
                        ),
                        row=1, col=1
                    )
        
        # Add long entry markers
        if entry_times_long:
            fig.add_trace(
                go.Scatter(
                    x=entry_times_long,
                    y=entry_prices_long,
                    mode='markers',
                    name='Long Entry',
                    marker=dict(
                        symbol='triangle-up',
                        size=12,
                        color=self.default_colors['long_entry'],
                        line=dict(width=1, color='white')
                    ),
                    hovertemplate='<b>Long Entry</b><br>Price: %{y}<br>Time: %{x}<extra></extra>'
                ),
                row=1, col=1
            )
        
        # Add short entry markers
        if entry_times_short:
            fig.add_trace(
                go.Scatter(
                    x=entry_times_short,
                    y=entry_prices_short,
                    mode='markers',
                    name='Short Entry',
                    marker=dict(
                        symbol='triangle-down',
                        size=12,
                        color=self.default_colors['short_entry'],
                        line=dict(width=1, color='white')
                    ),
                    hovertemplate='<b>Short Entry</b><br>Price: %{y}<br>Time: %{x}<extra></extra>'
                ),
                row=1, col=1
            )
        
        # Add exit markers
        if exit_times:
            fig.add_trace(
                go.Scatter(
                    x=exit_times,
                    y=exit_prices,
                    mode='markers',
                    name='Exit',
                    marker=dict(
                        symbol='x',
                        size=12,
                        color=self.default_colors['exit'],
                        line=dict(width=2, color='white')
                    ),
                    hovertemplate='<b>Exit</b><br>Price: %{y}<br>Time: %{x}<extra></extra>'
                ),
                row=1, col=1
            )
        
        logger.info(f"Added {len(trades)} trade markers to chart")
    
    def _add_journal_annotations(
        self,
        fig: go.Figure,
        journals: List[Dict[str, Any]],
        market_data: pd.DataFrame
    ):
        """
        Add journal entry annotations to the chart.
        
        Args:
            fig: Plotly figure
            journals: List of journal dictionaries
            market_data: Market data DataFrame
        """
        journal_times = []
        journal_prices = []
        journal_texts = []
        
        for journal in journals:
            if journal.get('timestamp'):
                # Find the closest price point
                timestamp = pd.to_datetime(journal['timestamp'])
                closest_idx = (market_data['timestamp'] - timestamp).abs().idxmin()
                price = market_data.loc[closest_idx, 'high']
                
                journal_times.append(timestamp)
                journal_prices.append(price)
                
                # Create hover text
                content = journal.get('content', '')[:100]  # Truncate long entries
                emotional_state = journal.get('emotional_state', 'N/A')
                tags = ', '.join(journal.get('tags', [])[:3])  # Show first 3 tags
                
                hover_text = f"<b>Journal Entry</b><br>{content}...<br><b>Emotion:</b> {emotional_state}<br><b>Tags:</b> {tags}"
                journal_texts.append(hover_text)
        
        if journal_times:
            fig.add_trace(
                go.Scatter(
                    x=journal_times,
                    y=journal_prices,
                    mode='markers',
                    name='Journal',
                    marker=dict(
                        symbol='circle',
                        size=10,
                        color=self.default_colors['journal'],
                        line=dict(width=2, color='black')
                    ),
                    text=journal_texts,
                    hovertemplate='%{text}<extra></extra>'
                ),
                row=1, col=1
            )
        
        logger.info(f"Added {len(journals)} journal annotations to chart")
    
    def _add_atr_indicator(self, fig: go.Figure, market_data: pd.DataFrame):
        """Add ATR (Average True Range) indicator to chart."""
        if 'atr' in market_data.columns:
            fig.add_trace(
                go.Scatter(
                    x=market_data['timestamp'],
                    y=market_data['atr'],
                    mode='lines',
                    name='ATR',
                    line=dict(color='rgba(255, 255, 255, 0.5)', width=1),
                    yaxis='y2'
                ),
                row=1, col=1
            )
            
            # Add secondary y-axis for ATR
            fig.update_layout(
                yaxis2=dict(
                    title='ATR',
                    overlaying='y',
                    side='right',
                    showgrid=False
                )
            )
    
    def _create_empty_chart(self, symbol: str) -> go.Figure:
        """Create an empty placeholder chart."""
        fig = go.Figure()
        fig.add_annotation(
            text=f"No market data available for {symbol}",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font=dict(size=20)
        )
        fig.update_layout(
            title=f"{symbol} Price Chart",
            height=600,
            template='plotly_dark'
        )
        return fig
    
    def create_equity_curve(self, trades: List[Dict[str, Any]]) -> go.Figure:
        """
        Create an equity curve chart showing cumulative P&L over time.
        
        Args:
            trades: List of trade dictionaries
        
        Returns:
            Plotly Figure object
        """
        if not trades:
            return self._create_empty_chart("Equity Curve")
        
        df = pd.DataFrame(trades)
        df = df.sort_values('entry_time')
        df['cumulative_pnl'] = df['pnl'].cumsum()
        
        fig = go.Figure()
        
        # Add equity curve
        fig.add_trace(
            go.Scatter(
                x=df['entry_time'],
                y=df['cumulative_pnl'],
                mode='lines',
                name='Equity',
                line=dict(color='#2196f3', width=2),
                fill='tozeroy',
                fillcolor='rgba(33, 150, 243, 0.1)'
            )
        )
        
        # Add zero line
        fig.add_hline(
            y=0,
            line_dash="dash",
            line_color="gray",
            annotation_text="Break Even"
        )
        
        fig.update_layout(
            title="Equity Curve",
            xaxis_title="Time",
            yaxis_title="Cumulative P&L ($)",
            height=500,
            template='plotly_dark',
            hovermode='x unified'
        )
        
        logger.info("Created equity curve chart")
        return fig
    
    def create_win_loss_distribution(self, trades: List[Dict[str, Any]]) -> go.Figure:
        """
        Create a win/loss distribution chart.
        
        Args:
            trades: List of trade dictionaries
        
        Returns:
            Plotly Figure object
        """
        if not trades:
            return self._create_empty_chart("Win/Loss Distribution")
        
        df = pd.DataFrame(trades)
        winners = df[df['pnl'] > 0]['pnl']
        losers = df[df['pnl'] < 0]['pnl']
        
        fig = go.Figure()
        
        # Add winners histogram
        fig.add_trace(
            go.Histogram(
                x=winners,
                name='Winners',
                marker_color='green',
                opacity=0.7,
                nbinsx=20
            )
        )
        
        # Add losers histogram
        fig.add_trace(
            go.Histogram(
                x=losers,
                name='Losers',
                marker_color='red',
                opacity=0.7,
                nbinsx=20
            )
        )
        
        fig.update_layout(
            title="Win/Loss Distribution",
            xaxis_title="P&L ($)",
            yaxis_title="Frequency",
            height=500,
            template='plotly_dark',
            barmode='overlay'
        )
        
        logger.info("Created win/loss distribution chart")
        return fig
    
    def create_symbol_performance(self, trades: List[Dict[str, Any]]) -> go.Figure:
        """
        Create a symbol performance comparison chart.
        
        Args:
            trades: List of trade dictionaries
        
        Returns:
            Plotly Figure object
        """
        if not trades:
            return self._create_empty_chart("Symbol Performance")
        
        df = pd.DataFrame(trades)
        symbol_stats = df.groupby('symbol').agg({
            'pnl': ['sum', 'mean', 'count']
        }).reset_index()
        
        fig = go.Figure()
        
        # Add bar chart for total P&L by symbol
        fig.add_trace(
            go.Bar(
                x=symbol_stats['symbol'],
                y=symbol_stats[('pnl', 'sum')],
                name='Total P&L',
                marker_color=['green' if x > 0 else 'red' for x in symbol_stats[('pnl', 'sum')]]
            )
        )
        
        fig.update_layout(
            title="Performance by Symbol",
            xaxis_title="Symbol",
            yaxis_title="Total P&L ($)",
            height=500,
            template='plotly_dark'
        )
        
        logger.info("Created symbol performance chart")
        return fig
