"""
Authentication and subscription management module.
Handles Supabase Auth integration and Stripe subscription management.
"""

from supabase import Client
from config.config import Config
import streamlit as st
from typing import Optional, Dict, Any
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AuthManager:
    """
    Manager for user authentication and session management.
    """
    
    def __init__(self, supabase_client: Client):
        """
        Initialize auth manager with Supabase client.
        
        Args:
            supabase_client: Supabase client instance
        """
        self.client = supabase_client
    
    def login(self, email: str, password: str) -> Optional[Dict[str, Any]]:
        """
        Authenticate user with email and password.
        
        Args:
            email: User email
            password: User password
        
        Returns:
            User data dictionary or None if authentication fails
        """
        try:
            response = self.client.auth.sign_in_with_password({
                "email": email,
                "password": password
            })
            
            if response.user:
                logger.info(f"User logged in: {email}")
                return {
                    "id": response.user.id,
                    "email": response.user.email,
                    "session": response.session
                }
            else:
                logger.warning(f"Login failed for: {email}")
                return None
        
        except Exception as e:
            logger.error(f"Login error: {e}")
            return None
    
    def signup(self, email: str, password: str) -> Optional[Dict[str, Any]]:
        """
        Register a new user.
        
        Args:
            email: User email
            password: User password
        
        Returns:
            User data dictionary or None if signup fails
        """
        try:
            response = self.client.auth.sign_up({
                "email": email,
                "password": password
            })
            
            if response.user:
                logger.info(f"User signed up: {email}")
                return {
                    "id": response.user.id,
                    "email": response.user.email
                }
            else:
                logger.warning(f"Signup failed for: {email}")
                return None
        
        except Exception as e:
            logger.error(f"Signup error: {e}")
            return None
    
    def logout(self):
        """Log out the current user."""
        try:
            self.client.auth.sign_out()
            logger.info("User logged out")
        except Exception as e:
            logger.error(f"Logout error: {e}")
    
    def get_current_user(self) -> Optional[Dict[str, Any]]:
        """
        Get the currently authenticated user.
        
        Returns:
            User data dictionary or None if not authenticated
        """
        try:
            user = self.client.auth.get_user()
            if user:
                return {
                    "id": user.id,
                    "email": user.email
                }
            return None
        except Exception as e:
            logger.error(f"Error getting current user: {e}")
            return None
    
    def reset_password(self, email: str) -> bool:
        """
        Send password reset email.
        
        Args:
            email: User email
        
        Returns:
            True if email sent successfully
        """
        try:
            self.client.auth.reset_password_for_email(email)
            logger.info(f"Password reset email sent to: {email}")
            return True
        except Exception as e:
            logger.error(f"Password reset error: {e}")
            return False

class SubscriptionManager:
    """
    Manager for subscription and payment processing with Stripe.
    """
    
    def __init__(self):
        """Initialize subscription manager."""
        self.stripe_api_key = Config.STRIPE_API_KEY
        # Note: stripe library would be imported here
        # import stripe
        # stripe.api_key = self.stripe_api_key
    
    def create_checkout_session(
        self,
        user_id: str,
        price_id: str,
        success_url: str,
        cancel_url: str
    ) -> Optional[str]:
        """
        Create a Stripe checkout session for subscription.
        
        Args:
            user_id: User ID
            price_id: Stripe price ID
            success_url: URL to redirect on success
            cancel_url: URL to redirect on cancel
        
        Returns:
            Checkout session URL or None
        """
        try:
            # This is a placeholder implementation
            # In production, you would use the Stripe API:
            # session = stripe.checkout.Session.create(
            #     customer_email=user_email,
            #     payment_method_types=['card'],
            #     line_items=[{
            #         'price': price_id,
            #         'quantity': 1,
            #     }],
            #     mode='subscription',
            #     success_url=success_url,
            #     cancel_url=cancel_url,
            #     metadata={'user_id': user_id}
            # )
            # return session.url
            
            logger.info(f"Checkout session created for user: {user_id}")
            return "https://checkout.stripe.com/placeholder"
        
        except Exception as e:
            logger.error(f"Error creating checkout session: {e}")
            return None
    
    def get_subscription_status(self, user_id: str) -> Dict[str, Any]:
        """
        Get subscription status for a user.
        
        Args:
            user_id: User ID
        
        Returns:
            Dictionary with subscription status
        """
        # This is a placeholder implementation
        # In production, you would query Stripe API or your database
        return {
            "tier": "free",
            "status": "active",
            "current_period_end": None,
            "cancel_at_period_end": False
        }
    
    def cancel_subscription(self, subscription_id: str) -> bool:
        """
        Cancel a subscription.
        
        Args:
            subscription_id: Stripe subscription ID
        
        Returns:
            True if successful
        """
        try:
            # This is a placeholder implementation
            # In production: stripe.Subscription.modify(subscription_id, cancel_at_period_end=True)
            logger.info(f"Subscription cancelled: {subscription_id}")
            return True
        except Exception as e:
            logger.error(f"Error cancelling subscription: {e}")
            return False

# Streamlit-specific authentication helpers

def render_login_page():
    """Render login page in Streamlit."""
    st.title("🔐 Login")
    
    with st.form("login_form"):
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        submit = st.form_submit_button("Login")
        
        if submit:
            if email and password:
                # This would use AuthManager.login()
                st.success("Login functionality will be implemented with Supabase Auth")
            else:
                st.error("Please enter both email and password")
    
    st.divider()
    
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Don't have an account? Sign up"):
            st.session_state.show_signup = True
    with col2:
        if st.button("Forgot password?"):
            st.session_state.show_reset = True

def render_signup_page():
    """Render signup page in Streamlit."""
    st.title("📝 Sign Up")
    
    with st.form("signup_form"):
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        password_confirm = st.text_input("Confirm Password", type="password")
        submit = st.form_submit_button("Sign Up")
        
        if submit:
            if email and password and password_confirm:
                if password == password_confirm:
                    # This would use AuthManager.signup()
                    st.success("Signup functionality will be implemented with Supabase Auth")
                else:
                    st.error("Passwords do not match")
            else:
                st.error("Please fill in all fields")
    
    st.divider()
    
    if st.button("Already have an account? Login"):
        st.session_state.show_signup = False

def render_subscription_page():
    """Render subscription management page."""
    st.title("💳 Subscription Management")
    
    # Display current subscription status
    st.subheader("Current Plan")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("### Free")
        st.markdown("- 2-5 users")
        st.markdown("- Basic analytics")
        st.markdown("- 30 days data retention")
        st.markdown("**$0/month**")
        st.button("Current Plan", disabled=True)
    
    with col2:
        st.markdown("### Basic")
        st.markdown("- Up to 10 users")
        st.markdown("- Advanced analytics")
        st.markdown("- 90 days data retention")
        st.markdown("- AI insights")
        st.markdown("**$19/month**")
        if st.button("Upgrade to Basic"):
            st.info("Stripe checkout will be implemented here")
    
    with col3:
        st.markdown("### Premium")
        st.markdown("- Unlimited users")
        st.markdown("- Full analytics suite")
        st.markdown("- Unlimited data retention")
        st.markdown("- Priority support")
        st.markdown("- Custom integrations")
        st.markdown("**$49/month**")
        if st.button("Upgrade to Premium"):
            st.info("Stripe checkout will be implemented here")
    
    st.divider()
    
    st.subheader("Billing History")
    st.info("Billing history will be displayed here once Stripe integration is complete")

def check_authentication() -> bool:
    """
    Check if user is authenticated in Streamlit session.
    
    Returns:
        True if authenticated, False otherwise
    """
    return st.session_state.get('user_authenticated', False)

def require_authentication():
    """
    Decorator/helper to require authentication for a page.
    Redirects to login if not authenticated.
    """
    if not check_authentication():
        render_login_page()
        st.stop()
    return True
