"""
Sample Data Generator for Phase 2 AI Analysis App.
Generates realistic trading data, journal entries, and market data for testing and demonstration.
"""

import random
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Any
import json


class SampleDataGenerator:
    """Generate realistic sample data for testing the application."""
    
    def __init__(self, seed: int = 42):
        """
        Initialize the sample data generator.
        
        Args:
            seed: Random seed for reproducibility
        """
        random.seed(seed)
        np.random.seed(seed)
        
        self.symbols = ['MES', 'MGC', 'M2K']
        self.emotional_states = ['confident', 'anxious', 'neutral', 'frustrated', 'excited', 'calm']
        self.tags = ['breakout', 'reversal', 'trend_following', 'scalp', 'swing', 'news_driven', 'technical', 'fundamental']
        self.sessions = ['asian', 'london', 'new_york', 'overlap']
        
    def generate_trades(self, num_trades: int = 50, start_date: datetime = None) -> List[Dict[str, Any]]:
        """
        Generate realistic trade data.
        
        Args:
            num_trades: Number of trades to generate
            start_date: Starting date for trades
        
        Returns:
            List of trade dictionaries
        """
        if start_date is None:
            start_date = datetime.now() - timedelta(days=90)
        
        trades = []
        cumulative_pnl = 0
        
        for i in range(num_trades):
            # Generate entry time
            entry_time = start_date + timedelta(
                days=random.randint(0, 90),
                hours=random.randint(6, 20),
                minutes=random.randint(0, 59)
            )
            
            # Select symbol
            symbol = random.choice(self.symbols)
            
            # Generate direction
            direction = random.choice(['long', 'short'])
            
            # Generate entry price based on symbol
            if symbol == 'MES':
                entry_price = random.uniform(4500, 5500)
                tick_value = 1.25
            elif symbol == 'MGC':
                entry_price = random.uniform(1800, 2200)
                tick_value = 1.0
            else:  # M2K
                entry_price = random.uniform(1900, 2100)
                tick_value = 0.5
            
            # Generate hold time (in minutes)
            hold_time = int(np.random.lognormal(mean=3, sigma=1.5))  # Log-normal distribution
            hold_time = min(hold_time, 480)  # Cap at 8 hours
            
            # Generate exit time
            exit_time = entry_time + timedelta(minutes=hold_time)
            
            # Generate price movement
            volatility = random.uniform(0.001, 0.005)
            price_change = entry_price * volatility * random.choice([-1, 1])
            
            # Introduce win/loss bias (55% win rate)
            if random.random() < 0.55:
                # Winning trade
                price_change = abs(price_change) * random.uniform(1, 3)
            else:
                # Losing trade
                price_change = -abs(price_change) * random.uniform(0.5, 1.5)
            
            exit_price = entry_price + (price_change if direction == 'long' else -price_change)
            
            # Calculate P&L
            ticks = abs(exit_price - entry_price) / (tick_value / 10)
            pnl = ticks * tick_value * (1 if (exit_price > entry_price and direction == 'long') or (exit_price < entry_price and direction == 'short') else -1)
            
            # Generate MFE and MAE
            if pnl > 0:
                mfe = abs(pnl) * random.uniform(1.2, 2.5)  # MFE is larger than final P&L
                mae = abs(pnl) * random.uniform(0.1, 0.8)  # MAE is smaller
            else:
                mfe = abs(pnl) * random.uniform(0.2, 0.6)  # MFE is smaller than final loss
                mae = abs(pnl) * random.uniform(1.0, 1.8)  # MAE is larger
            
            cumulative_pnl += pnl
            
            # Generate contracts
            contracts = random.choice([1, 2, 3, 5])
            
            trade = {
                'id': f'trade_{i+1}',
                'symbol': symbol,
                'direction': direction,
                'entry_time': entry_time.isoformat(),
                'exit_time': exit_time.isoformat(),
                'entry_price': round(entry_price, 2),
                'exit_price': round(exit_price, 2),
                'contracts': contracts,
                'pnl': round(pnl * contracts, 2),
                'mfe': round(mfe * contracts, 2),
                'mae': round(-mae * contracts, 2),
                'hold_time_minutes': hold_time,
                'cumulative_pnl': round(cumulative_pnl, 2),
                'session': random.choice(self.sessions),
                'setup_type': random.choice(['breakout', 'pullback', 'reversal', 'continuation'])
            }
            
            trades.append(trade)
        
        return trades
    
    def generate_journals(self, trades: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Generate journal entries corresponding to trades.
        
        Args:
            trades: List of trade dictionaries
        
        Returns:
            List of journal dictionaries
        """
        journals = []
        
        for i, trade in enumerate(trades):
            # 70% of trades have journal entries
            if random.random() < 0.7:
                entry_time = datetime.fromisoformat(trade['entry_time'])
                
                # Journal is created within 1 hour of trade
                journal_time = entry_time + timedelta(minutes=random.randint(-30, 30))
                
                # Select emotional state
                emotional_state = random.choice(self.emotional_states)
                
                # Generate plan adherence score (1-10)
                plan_adherence = random.randint(1, 10)
                
                # Generate tags
                num_tags = random.randint(1, 3)
                selected_tags = random.sample(self.tags, num_tags)
                
                # Generate content based on emotional state and outcome
                content_templates = {
                    'confident': "Feeling confident about this setup. Market conditions look favorable. Following my plan strictly.",
                    'anxious': "A bit anxious about this trade. Market seems choppy. Need to stick to my stops.",
                    'neutral': "Standard setup. Following the plan. No strong emotions either way.",
                    'frustrated': "Frustrated with recent losses. Trying to stay disciplined and not revenge trade.",
                    'excited': "Excited about this opportunity! Setup looks perfect. Need to manage position size.",
                    'calm': "Calm and focused. Market is clear. Executing according to plan."
                }
                
                content = content_templates.get(emotional_state, "Trade journal entry.")
                
                # Add trade-specific details
                content += f" Trading {trade['symbol']} {trade['direction']}. Entry at {trade['entry_price']}."
                
                journal = {
                    'id': f'journal_{i+1}',
                    'timestamp': journal_time.isoformat(),
                    'symbol': trade['symbol'],
                    'emotional_state': emotional_state,
                    'plan_adherence_score': plan_adherence,
                    'tags': selected_tags,
                    'content': content,
                    'trade_id': trade['id']
                }
                
                journals.append(journal)
        
        return journals
    
    def generate_market_data(
        self,
        symbol: str,
        start_date: datetime,
        end_date: datetime,
        interval_minutes: int = 5
    ) -> pd.DataFrame:
        """
        Generate realistic candlestick market data.
        
        Args:
            symbol: Trading symbol
            start_date: Start date for data
            end_date: End date for data
            interval_minutes: Candle interval in minutes
        
        Returns:
            DataFrame with OHLCV data
        """
        # Generate timestamps
        timestamps = pd.date_range(start=start_date, end=end_date, freq=f'{interval_minutes}min')
        
        # Base price for each symbol
        base_prices = {
            'MES': 5000,
            'MGC': 2000,
            'M2K': 2000
        }
        
        base_price = base_prices.get(symbol, 5000)
        
        # Generate price series using random walk
        num_candles = len(timestamps)
        returns = np.random.normal(0, 0.002, num_candles)  # 0.2% volatility
        price_series = base_price * np.exp(np.cumsum(returns))
        
        # Generate OHLCV data
        data = []
        for i, (timestamp, close) in enumerate(zip(timestamps, price_series)):
            # Generate open, high, low based on close
            open_price = close * random.uniform(0.998, 1.002)
            high = max(open_price, close) * random.uniform(1.0, 1.003)
            low = min(open_price, close) * random.uniform(0.997, 1.0)
            volume = random.randint(1000, 10000)
            
            data.append({
                'timestamp': timestamp,
                'symbol': symbol,
                'open': round(open_price, 2),
                'high': round(high, 2),
                'low': round(low, 2),
                'close': round(close, 2),
                'volume': volume
            })
        
        return pd.DataFrame(data)
    
    def save_sample_data(self, output_dir: str = '/home/ubuntu/manus_app/data'):
        """
        Generate and save all sample data to files.
        
        Args:
            output_dir: Directory to save sample data
        """
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        # Generate trades
        trades = self.generate_trades(num_trades=100)
        
        # Generate journals
        journals = self.generate_journals(trades)
        
        # Save to JSON
        with open(f'{output_dir}/sample_trades.json', 'w') as f:
            json.dump(trades, f, indent=2)
        
        with open(f'{output_dir}/sample_journals.json', 'w') as f:
            json.dump(journals, f, indent=2)
        
        # Generate market data for each symbol
        start_date = datetime.now() - timedelta(days=90)
        end_date = datetime.now()
        
        for symbol in self.symbols:
            market_data = self.generate_market_data(symbol, start_date, end_date)
            market_data.to_csv(f'{output_dir}/sample_market_data_{symbol}.csv', index=False)
        
        print(f"Sample data generated and saved to {output_dir}")
        print(f"- {len(trades)} trades")
        print(f"- {len(journals)} journal entries")
        print(f"- Market data for {len(self.symbols)} symbols")


if __name__ == '__main__':
    generator = SampleDataGenerator()
    generator.save_sample_data()

