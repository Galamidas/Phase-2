
"""
Automated tests for the core functionalities of the Phase 2 AI Analysis App.
"""

import unittest
import pandas as pd
from datetime import datetime, timedelta
import json
import os

# Assuming the following modules are available in the path
from src.analysis.trade_analytics import TradeAnalytics
from src.analysis.predictive_engine_enhanced import EnhancedPredictiveEngine
from src.utils.sample_data_generator import SampleDataGenerator

class TestCoreFunctionality(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        """Set up sample data for all tests."""
        cls.data_dir = ".test_data"
        os.makedirs(cls.data_dir, exist_ok=True)
        
        generator = SampleDataGenerator(seed=123)
        
        # Generate and save sample data to a temporary directory
        cls.trades = generator.generate_trades(num_trades=50)
        cls.journals = generator.generate_journals(cls.trades)
        cls.market_data_mes = generator.generate_market_data(
            symbol='MES', 
            start_date=datetime.now() - timedelta(days=60), 
            end_date=datetime.now()
        )
        
        with open(f'{cls.data_dir}/sample_trades.json', 'w') as f:
            json.dump(cls.trades, f, indent=2)
        with open(f'{cls.data_dir}/sample_journals.json', 'w') as f:
            json.dump(cls.journals, f, indent=2)
        cls.market_data_mes.to_csv(f'{cls.data_dir}/sample_market_data_MES.csv', index=False)

    @classmethod
    def tearDownClass(cls):
        """Clean up generated sample data."""
        os.remove(f'{cls.data_dir}/sample_trades.json')
        os.remove(f'{cls.data_dir}/sample_journals.json')
        os.remove(f'{cls.data_dir}/sample_market_data_MES.csv')
        os.rmdir(cls.data_dir)

    def test_trade_analytics_calculation(self):
        """Test basic trade analytics calculations."""
        analytics = TradeAnalytics(self.trades)
        summary = analytics.get_performance_summary()
        
        self.assertIn('total_trades', summary)
        self.assertGreater(summary['total_trades'], 0)
        self.assertIn('win_rate', summary)
        self.assertIn('profit_factor', summary)
        self.assertIn('total_pnl', summary)
        
        # Test specific calculations if trades are available
        if summary['total_trades'] > 0:
            self.assertIsInstance(summary['win_rate'], float)
            self.assertIsInstance(summary['profit_factor'], float)
            self.assertIsInstance(summary["total_pnl"], float)

    def test_predictive_engine_initialization(self):
        """Test initialization of the enhanced predictive engine."""
        engine = EnhancedPredictiveEngine(self.trades, self.journals, self.market_data_mes)
        self.assertFalse(engine.trades_df.empty)
        self.assertFalse(engine.journals_df.empty)
        self.assertFalse(engine.market_data.empty)
        self.assertFalse(engine.merged_data.empty)

    def test_predictive_engine_pattern_discovery(self):
        """Test novel pattern discovery in the enhanced predictive engine."""
        engine = EnhancedPredictiveEngine(self.trades, self.journals, self.market_data_mes)
        patterns = engine.discover_novel_patterns()
        
        self.assertIsInstance(patterns, list)
        # We expect some patterns to be discovered with sufficient data
        # self.assertGreater(len(patterns), 0) # This might be 0 depending on data distribution

    def test_predictive_engine_prescriptive_recommendations(self):
        """Test generation of prescriptive recommendations."""
        engine = EnhancedPredictiveEngine(self.trades, self.journals, self.market_data_mes)
        recommendations = engine.generate_prescriptive_recommendations()
        
        self.assertIsInstance(recommendations, list)
        # self.assertGreater(len(recommendations), 0) # This might be 0 depending on data distribution

    def test_predictive_engine_cross_reference_analysis(self):
        """Test advanced cross-reference analysis."""
        engine = EnhancedPredictiveEngine(self.trades, self.journals, self.market_data_mes)
        analysis_results = engine.advanced_cross_reference()
        
        self.assertIn('correlations', analysis_results)
        self.assertIn('insights', analysis_results)
        self.assertIn('causal_relationships', analysis_results)
        self.assertIsInstance(analysis_results['correlations'], list)
        self.assertIsInstance(analysis_results['insights'], list)
        self.assertIsInstance(analysis_results['causal_relationships'], list)

    def test_predictive_engine_explain_prediction(self):
        """Test explainable AI for predictions."""
        engine = EnhancedPredictiveEngine(self.trades, self.journals, self.market_data_mes)
        # Create a dummy prediction for testing XAI
        dummy_prediction = {
            'probability': 0.65,
            'confidence': 'medium',
            'recommendation': 'Consider taking this trade',
            'factors': [
                {'factor': 'Symbol Performance', 'impact': 0.1, 'description': 'MES historical win rate: 60%'},
                {'factor': 'Emotional State', 'impact': 0.05, 'description': 'Confident state win rate: 70%'}
            ]
        }
        explanation = engine.explain_prediction(dummy_prediction)
        
        self.assertIn('prediction_summary', explanation)
        self.assertIn('factor_breakdown', explanation)
        self.assertIn('decision_path', explanation)
        self.assertIn('counterfactuals', explanation)
        self.assertGreater(len(explanation['factor_breakdown']), 0)

if __name__ == '__main__':
    unittest.main()

