"""
Configuration module for Phase 2 AI Analysis App.
This module loads environment variables and provides centralized configuration management.
"""

import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Config:
    """
    Configuration class that holds all application settings.
    All sensitive credentials are loaded from environment variables.
    """
    
    # Supabase Configuration
    SUPABASE_URL = os.getenv("SUPABASE_URL", "")
    SUPABASE_KEY = os.getenv("SUPABASE_KEY", "")
    
    # OpenAI Configuration
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
    OPENAI_MODEL = "gpt-4o-mini"  # Cost-effective model for tagging and analysis
    
    # TopStep API Configuration
    TOPSTEP_API_KEY = os.getenv("TOPSTEP_API_KEY", "")
    TOPSTEP_API_URL = os.getenv("TOPSTEP_API_URL", "https://api.topstepx.com")
    
    # Databento Configuration
    DATABENTO_API_KEY = os.getenv("DATABENTO_API_KEY", "")
    
    # Stripe Configuration
    STRIPE_API_KEY = os.getenv("STRIPE_API_KEY", "")
    STRIPE_PUBLISHABLE_KEY = os.getenv("STRIPE_PUBLISHABLE_KEY", "")
    
    # OneSignal Configuration
    ONESIGNAL_APP_ID = os.getenv("ONESIGNAL_APP_ID", "")
    ONESIGNAL_REST_API_KEY = os.getenv("ONESIGNAL_REST_API_KEY", "")
    
    # Optional: AssemblyAI Configuration
    ASSEMBLYAI_API_KEY = os.getenv("ASSEMBLYAI_API_KEY", "")
    
    # Optional: Discord Bot Configuration
    DISCORD_BOT_TOKEN = os.getenv("DISCORD_BOT_TOKEN", "")
    DISCORD_CHANNEL_ID = os.getenv("DISCORD_CHANNEL_ID", "")
    DISCORD_ENABLED = os.getenv("DISCORD_ENABLED", "False").lower() == "true"
    
    # Application Configuration
    APP_ENV = os.getenv("APP_ENV", "development")
    DEBUG_MODE = os.getenv("DEBUG_MODE", "True").lower() == "true"
    
    # Trading Symbols
    SUPPORTED_SYMBOLS = ["MGC", "MES", "M2K"]  # Micro Gold, Micro E-mini S&P 500, Micro E-mini Russell 2000
    
    # Analysis Configuration
    MAX_OPENAI_TOKENS = 500  # Limit tokens to control costs
    ANALYSIS_LOOKBACK_DAYS = 90  # Default lookback period for analysis
    
    # Database Tables
    TABLE_JOURNALS = "journals"
    TABLE_TRADES = "trades"
    TABLE_MARKET_DATA = "market_data"
    TABLE_TAGS = "tags"
    TABLE_DISCORD_MESSAGES = "discord_messages"
    TABLE_USERS = "users"
    
    @classmethod
    def validate(cls):
        """
        Validate that all required configuration variables are set.
        Returns a list of missing configuration keys.
        """
        required_keys = [
            ("SUPABASE_URL", cls.SUPABASE_URL),
            ("SUPABASE_KEY", cls.SUPABASE_KEY),
            ("OPENAI_API_KEY", cls.OPENAI_API_KEY),
        ]
        
        missing = [key for key, value in required_keys if not value]
        return missing
    
    @classmethod
    def get_summary(cls):
        """
        Get a summary of the current configuration (without exposing sensitive data).
        """
        return {
            "app_env": cls.APP_ENV,
            "debug_mode": cls.DEBUG_MODE,
            "supported_symbols": cls.SUPPORTED_SYMBOLS,
            "openai_model": cls.OPENAI_MODEL,
            "discord_enabled": cls.DISCORD_ENABLED,
            "supabase_configured": bool(cls.SUPABASE_URL and cls.SUPABASE_KEY),
            "openai_configured": bool(cls.OPENAI_API_KEY),
            "topstep_configured": bool(cls.TOPSTEP_API_KEY),
            "databento_configured": bool(cls.DATABENTO_API_KEY),
        }
